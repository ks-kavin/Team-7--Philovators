# About the data

All data here is **fictional**: invented companies, products and prices.

## The story

Two companies sell products:

| File | Company | What they sell | IDs start with |
|---|---|---|---|
| `electronics_catalog.xlsx` | CircuitNova | Electronic modules (displays, power units, network cards, ...) | `E` |
| `home_appliances_catalog.xlsx` | Hearthwell | Appliance parts (cooling, water care, laundry, ...) | `H` |

Inside each company, **different teams keep their own list** about the same products. That's why each
file has 5 sheets. The lists are supposed to agree, **but they don't always**. Finding where they
disagree is a big part of what your agent will do.

The `policies-word/` folder holds the company **rules** as Word files (pricing, export control, service, product lifecycle,
data ownership). The Excel files tell you **what is**; the policies tell you **what should be**.

## Products and options

A **product** is the main thing you sell. An **option** is a choice or add-on for that product.

> Think of buying a car. The **product** is "Model X". The **options** are "sunroof", "leather seats",
> "3-year service plan". Each option has its own price.

In this data a product looks like `EP-1007` ("CircuitNova Signal Processing Module 1007") and its options
look like `EO-10001`. One product can have many options, and **most sheets have one row per option**.
So *number of rows ≠ number of products*.

## The 5 sheets

| Sheet | Kept by | Answers the question |
|---|---|---|
| `products` | Product team | What products exist, and what options do they have? (the master list) |
| `where_we_sell` | Sales team | Where and from when can we sell it? Should it have a price? Is service offered? |
| `product_validity` | Admin / ERP team | Who owns it, and until when is it valid? |
| `price_list` | Pricing team | What does each option cost us and sell for, per country? |
| `third_party_parts` | Purchasing team | Which third-party parts do we buy from suppliers, and for which product? |

## How they connect

`products` is the centre. Every other sheet points back to it:

```
                         products
               (every product and its options)
         ┌────────────┬─────────┴─────────┬──────────────┐
   product_id    product_id           option_id      linked_product_id
         │            │                   │              │
where_we_sell       product_validity   price_list    third_party_parts
"can we sell it?"  "still valid?"     "how much?"   "which parts?"
```

## One product through all 5 sheets

Product **`EP-1007`** (Signal Processing Module), option **`EO-10001`**:

| Sheet | What it says |
|---|---|
| `products` | EP-1007 has 3 options: EO-10001, EO-10966, EO-10967 |
| `where_we_sell` | Sellable from 2025-01-11 in DK, FR, GB, SE, US. EO-10001 **should have a price** |
| `product_validity` | Owned by Owner-01, valid until 9999-12-31 (never expires) |
| `price_list` | EO-10001 in Denmark: **price missing** |
| `third_party_parts` | No third-party parts |

So sales expects a price for EO-10001, but the pricing team has none for Denmark. That's a problem
only visible when you **combine two sheets**.

## Words we use

When people in the company ask questions, these words have one meaning:

| Word | Means | Sheet |
|---|---|---|
| **sell / selling / sellable** | The product has a row in `where_we_sell`. Nothing else is needed. | `where_we_sell` |
| **expired** | `valid_to` is before today | `product_validity` |
| **missing price** | `price_status` = `Cost and list price missing` and `is_npi` = `No` | `price_list` |
| **pricing problem** | A missing price, or `price_status` = `List price not refreshed` | `price_list` |
| **below minimum margin** | `list_price` < 1.2 × `cost_price` (free items with both prices 0 don't count) | `price_list` |
| **controlled** | `export_class` is `EC-1` or `EC-2` | `products` |

## Columns

### `products`
| Column | Meaning |
|---|---|
| `product_id`, `product_name` | The product |
| `option_id`, `option_name` | The option (empty on the product's own base row) |
| `item_type` | Product, Option, Feature, Service, Child Product, ... |
| `business_unit` | Which part of the company owns it |
| `country_of_origin` | Where it's made (two-letter code, e.g. `NL`). Empty if unknown |
| `export_class` | `EC-0` = not controlled, `EC-1` or `EC-2` = controlled (see the export control policy). Same on every row of a product |
| `quotable_countries` | Countries where it may be sold, separated by `;` |

### `where_we_sell`
| Column | Meaning |
|---|---|
| `product_id` ... `option_name` | Same as `products` |
| `has_price` | `Yes` = sales expects this option to have a price in `price_list` |
| `valid_from` | Date from which sales may offer it |
| `quotable_countries` | Countries where sales may offer it |
| `serviceability` | `Serviceable` or `Non-Serviceable` |
| `service_plan`, `serviceable_countries` | Which service plan, and where service is offered (separated by `;`) |

### `product_validity`
| Column | Meaning |
|---|---|
| `product_id` ... `option_name` | Same as `products` |
| `owner_company` | Which company entity owns it |
| `business_unit` | Owning business unit, according to this team |
| `valid_from`, `valid_to` | Validity period. After `valid_to` the item is **expired** |

### `price_list` (one row per option per country)
| Column | Meaning |
|---|---|
| `option_id` | Links to `option_id` in the other sheets |
| `business_unit` | Owning business unit |
| `country`, `region`, `zone`, `currency` | Where the price applies |
| `cost_price` | What the item costs the company |
| `list_price` | Official selling price, before discounts |
| `price_status` | `Available`, `Cost and list price missing`, or `List price not refreshed` |
| `is_npi` | `Yes` = new product introduction (just launched) |

### `third_party_parts`
| Column | Meaning |
|---|---|
| `item_id`, `description` | The supplier part |
| `linked_product_id` | The product this part belongs to |
| `country_of_origin`, `distribution_countries` | Where it's made and where it may be shipped (two-letter codes, e.g. `NL`, separated by `;`) |
| `revision`, `created_on`, `updated_on` | Change history |
| `catalog_status` | `Effective`, `Obsolete` (no longer supplied), or `Not found in catalog` |
