# Sample questions

These are the kinds of questions your assistant must handle. They come from real people in the quoting
process. Judges will also ask **other questions you haven't seen**, so build an assistant that works
things out from the data and policies, not one that knows these answers by heart.

Save your assistant's answers to the 6 sample questions .

1. **Presales:** "Is product EP-1023 export-controlled? And where is it made?"

2. **Presales:** "A customer asks what the SVC-14 service plan covers. What do I tell them?"

3. **Presales lead:** "How many CircuitNova prices are missing and need fixing?"

4. **Presales:** "Can I quote option EO-10029 to a customer in the US?"

5. **Presales lead:** "Which CircuitNova products are we still selling even though they've expired?"

6. **Presales:** "A customer wants EP-5000 delivered to Germany. What's the price?"
