from __future__ import annotations

from datetime import date
from pathlib import Path
from typing import Any

import streamlit as st

from catalog_assistant.assistant import AssistantAnswer, CatalogAssistant
from catalog_assistant.llm_agent import answer_with_optional_llm


PROJECT_ROOT = Path(__file__).resolve().parent
SAMPLE_QUESTIONS = [
    "Is product EP-1023 export-controlled? And where is it made?",
    "A customer asks what the SVC-14 service plan covers. What do I tell them?",
    "How many CircuitNova prices are missing and need fixing?",
    "Can I quote option EO-10029 to a customer in the US?",
    "Which CircuitNova products are we still selling even though they've expired?",
    "A customer wants option EO-11534 delivered to Germany. What's the price?",
]
MORE_QUESTIONS = [
    "Audit catalog pricing issues.",
    "Does product EP-1023 have any third-party parts?",
    "Can SVC-14 be sold in India?",
    "Can I quote EP-1023 in Iran? Show other eligible destinations.",
]


@st.cache_resource(show_spinner="Loading catalogs and policies…")
def get_assistant() -> CatalogAssistant:
    return CatalogAssistant.from_project(PROJECT_ROOT)


@st.cache_data(ttl=90, show_spinner=False)
def get_health_snapshot(as_of_iso: str) -> dict[str, Any]:
    return get_assistant().health_snapshot(date.fromisoformat(as_of_iso))


def _serialize_answer(answer: AssistantAnswer) -> dict[str, Any]:
    return {
        "text": answer.text,
        "evidence": answer.evidence,
        "policies": [
            {
                "reference": policy.reference,
                "filename": policy.filename,
                "text": policy.text,
            }
            for policy in answer.policies
        ],
        "queries": answer.queries,
        "mode": answer.mode,
        "notice": answer.notice,
        "suggestions": answer.suggestions,
    }


def _display_suggestion_rows(suggestion: dict[str, Any]) -> list[dict[str, Any]]:
    if suggestion.get("kind") == "quote_alternatives":
        return [
            {
                "Country": f"{item.get('country_name', item.get('country'))} ({item.get('country')})",
                "Option": item.get("option_id") or "—",
                "List price": f"{item.get('currency', '')} {float(item.get('list_price', 0)):,.2f}",
                "Catalog region": item.get("region") or "Not recorded",
                "Same requested region": (
                    "Yes"
                    if item.get("same_catalog_region")
                    else "No"
                    if item.get("requested_region_recorded") and item.get("region")
                    else "Unknown"
                ),
            }
            for item in suggestion.get("items", [])
        ]
    if suggestion.get("kind") == "service_alternatives":
        return [
            {
                "Country": f"{item.get('country_name', item.get('country'))} ({item.get('country')})",
                "Current service records": item.get("coverage_records", 0),
            }
            for item in suggestion.get("items", [])
        ]
    return suggestion.get("items", [])


def _render_message(message: dict[str, Any]) -> None:
    with st.chat_message(message["role"]):
        st.markdown(message["text"])
        if message["role"] != "assistant":
            return
        if message.get("mode"):
            st.caption(f"Answer mode: {message['mode']}")
        if message.get("notice"):
            st.info(message["notice"])
        for suggestion in message.get("suggestions", []):
            with st.expander(suggestion.get("title", "Suggested next steps"), expanded=True):
                if suggestion.get("note"):
                    st.caption(suggestion["note"])
                if suggestion.get("items"):
                    st.dataframe(_display_suggestion_rows(suggestion), width="stretch", hide_index=True)

        if message.get("evidence"):
            with st.expander(f"Catalog evidence ({len(message['evidence'])} rows)"):
                st.dataframe(message["evidence"], width="stretch", hide_index=True)
        if message.get("policies"):
            with st.expander(f"Policy evidence ({len(message['policies'])} sections)"):
                for policy in message["policies"]:
                    st.markdown(f"**{policy['reference']}** · `{policy['filename']}`")
                    st.write(policy["text"])
        if message.get("queries"):
            with st.expander(f"Executed SQL ({len(message['queries'])} quer{'y' if len(message['queries']) == 1 else 'ies'})"):
                for index, query in enumerate(message["queries"], start=1):
                    st.caption(f"Query {index} · parameters: {query['params']}")
                    st.code(query["sql"], language="sql")


def _issue_expander(label: str, rows: list[dict[str, Any]]) -> None:
    with st.expander(f"{label} · {len(rows)}"):
        if rows:
            st.dataframe(rows, width="stretch", hide_index=True)
        else:
            st.caption("No flagged rows found.")


def _build_transcript(history: list[dict[str, Any]]) -> str:
    lines = ["# Catalog Assistant demo answers", ""]
    turn = 0
    for message in history:
        if message["role"] == "user":
            turn += 1
            lines.extend([f"## Question {turn}", "", message["text"], ""])
            continue
        lines.extend(["### Answer", "", message["text"], ""])
        if message.get("mode"):
            lines.extend([f"Answer mode: {message['mode']}", ""])
        policies = message.get("policies", [])
        if policies:
            lines.append("Policy references:")
            lines.extend(f"- {item['reference']} (`{item['filename']}`)" for item in policies)
            lines.append("")
        suggestions = message.get("suggestions", [])
        if suggestions:
            for suggestion in suggestions:
                lines.extend([f"**{suggestion.get('title', 'Suggestions')}**", ""])
                if suggestion.get("note"):
                    lines.extend([suggestion["note"], ""])
                for item in suggestion.get("items", []):
                    lines.append("- " + "; ".join(f"{key}: {value}" for key, value in item.items()))
                lines.append("")
        evidence = message.get("evidence", [])
        if evidence:
            lines.append("Catalog evidence rows:")
            for row in evidence:
                source_groups = (
                    ("_source_file", "_source_sheet", "_source_row"),
                    ("product_file", "product_sheet", "product_row"),
                    ("validity_file", "validity_sheet", "validity_row"),
                    ("sales_file", "sales_sheet", "sales_row"),
                    ("part_file", "part_sheet", "part_row"),
                )
                for group in source_groups:
                    source = " · ".join(str(row[key]) for key in group if row.get(key))
                    if source:
                        lines.append(f"- {source}")
            lines.append("")
    return "\n".join(lines).strip() + "\n"


st.set_page_config(page_title="Philips Catalog Assistant · Hackathon", page_icon="🔷", layout="wide")
st.markdown(
    """
    <style>
      [data-testid="stAppViewContainer"] { background: #ffffff; }
      [data-testid="stSidebar"] { background: #f3f8fb; border-right: 1px solid #d9e6ee; }
      [data-testid="stHeader"] { background: rgba(255,255,255,.92); }
      h1, h2, h3 { color: #092f55; letter-spacing: -0.025em; }
      [data-testid="stCaptionContainer"] { color: #536b7d; }
      [data-testid="stButton"] button { border-radius: 12px; border-color: #c8dbe7; }
      [data-testid="stButton"] button[kind="primary"] { background: #005eb8; border-color: #005eb8; color: white; }
      [data-testid="stChatMessage"] { border: 1px solid #e0e9ef; border-radius: 16px; padding: 1rem; }
      [data-testid="stChatInput"] { border-color: #b7d3e4; border-radius: 14px; }
      [data-testid="stAlert"] { border-left: 4px solid #00a5c8; border-radius: 10px; }
      [data-testid="stMetric"] { background: #f3f8fb; border: 1px solid #e0e9ef; padding: 14px; border-radius: 14px; }
    </style>
    """,
    unsafe_allow_html=True,
)
st.title("Catalog Assistant for presales")
st.caption("Philips inspired hackathon demo · Evidence backed answers from local product catalogs and policies.")

with st.sidebar:
    st.header("Demo controls")
    as_of = st.date_input("Evaluate validity as of", value=date.today())
    st.caption("Read-only: the source workbooks and catalog tables cannot be edited here.")

    if st.button("Clear conversation", width="stretch"):
        st.session_state.chat_history = []
        st.rerun()

    with st.expander("Sample questions", expanded=True):
        for index, sample in enumerate(SAMPLE_QUESTIONS, start=1):
            if st.button(sample, key=f"sample_{index}", width="stretch"):
                st.session_state.pending_question = sample
                st.rerun()
    with st.expander("More demo questions"):
        for index, sample in enumerate(MORE_QUESTIONS, start=1):
            if st.button(sample, key=f"more_sample_{index}", width="stretch"):
                st.session_state.pending_question = sample
                st.rerun()

if "chat_history" not in st.session_state:
    st.session_state.chat_history = []
if "pending_question" not in st.session_state:
    st.session_state.pending_question = ""
if st.session_state.chat_history:
    with st.sidebar:
        st.download_button(
            "Download answer log (.md)",
            data=_build_transcript(st.session_state.chat_history),
            file_name=f"catalog-assistant-answers-{date.today().isoformat()}.md",
            mime="text/markdown",
            width="stretch",
        )

try:
    assistant = get_assistant()
except Exception as exc:
    st.error(f"Could not load the catalogs or policy documents: {exc}")
    st.info("Check the files under data/catalogs and data/policies-word, then restart Streamlit.")
    st.stop()

chat_tab, health_tab, method_tab = st.tabs(["Ask the assistant", "Catalog health", "How it works"])

with chat_tab:
    if not st.session_state.chat_history:
        st.info("Choose a sample question in the sidebar or ask about a product, option, policy, or catalog issue.")
    for saved_message in st.session_state.chat_history:
        _render_message(saved_message)

    pending = st.session_state.pending_question
    typed_question = st.chat_input("For example: Can I quote EO-10029 in the US?")
    question = typed_question or pending
    if question:
        st.session_state.pending_question = ""
        st.session_state.chat_history.append({"role": "user", "text": question})
        with st.spinner("Checking catalog evidence and preparing the answer…"):
            answer = answer_with_optional_llm(assistant, question, as_of=as_of)
        st.session_state.chat_history.append({"role": "assistant", **_serialize_answer(answer)})
        st.rerun()

with health_tab:
    st.subheader("Read-only catalog checks")
    st.caption(f"Snapshot date: {as_of.isoformat()} · Source rows are loaded with pandas and checked in in-memory SQLite.")
    health = get_health_snapshot(as_of.isoformat())

    pricing_exceptions = (
        len(health["missing_price_rows"])
        + len(health["expected_price_gaps"])
        + len(health["stale_price_rows"])
        + len(health["margin_violations"])
    )
    parts_exceptions = len(health["obsolete_parts_in_sales"]) + len(health["orphaned_parts"])
    metric_columns = st.columns(5)
    metric_columns[0].metric("Product rows", sum(row["product_rows"] for row in health["product_rows_by_company"]))
    metric_columns[1].metric("Pricing exceptions", pricing_exceptions)
    metric_columns[2].metric(
        "Lifecycle listings",
        len(health["expired_listings"]) + len(health["not_yet_valid_listings"]),
    )
    metric_columns[3].metric("Export violations", len(health["embargo_violations"]))
    metric_columns[4].metric("Parts at risk / gaps", parts_exceptions)

    with st.expander("Loaded rows by sheet", expanded=False):
        st.dataframe(
            [{"Sheet": sheet, "Rows": count} for sheet, count in health["row_counts"].items()],
            width="stretch",
            hide_index=True,
        )
        st.dataframe(health["product_rows_by_company"], width="stretch", hide_index=True)

    st.markdown("#### Pricing")
    _issue_expander("Non-NPI rows with missing cost and list prices", health["missing_price_rows"])
    _issue_expander("NPI rows with price pending (tracked separately)", health["npi_pending_rows"])
    _issue_expander("Options marked as priced with no price-list row", health["expected_price_gaps"])
    _issue_expander("List prices that have not been refreshed", health["stale_price_rows"])
    _issue_expander("Margin, currency, or available-price issues", health["margin_violations"])

    st.markdown("#### Product and master data")
    _issue_expander("Expired items still listed for sale", health["expired_listings"])
    _issue_expander("Items listed before their valid-from date", health["not_yet_valid_listings"])
    _issue_expander("Products missing from a required system list", health["missing_system_records"])
    _issue_expander("Sales or validity rows missing from the product master", health["orphan_catalog_records"])
    _issue_expander("Business-unit conflicts with the product master", health["business_unit_conflicts"])
    _issue_expander("Products missing business unit, export class, or country of origin", health["incomplete_products"])

    st.markdown("#### Compliance, parts, and service")
    _issue_expander("Controlled products listed in embargoed countries", health["embargo_violations"])
    _issue_expander("Obsolete supplier parts linked to products still listed for sale", health["obsolete_parts_in_sales"])
    _issue_expander("Supplier parts with missing product links", health["orphaned_parts"])
    _issue_expander("Service records with missing or conflicting fields", health["service_issues"])

with method_tab:
    st.subheader("Evidence-first design")
    st.markdown(
        """
        1. **Load:** pandas reads the two Excel workbooks and the policy loader extracts numbered Word sections.
        2. **Find catalog facts:** fixed parameterized SQL queries check exact product IDs, prices, country eligibility, lifecycle, and supplier parts.
        3. **Find policy text:** a local keyword retriever ranks sections from the supplied Word policies. No embedding service is called.
        4. **Explain:** deterministic Python checks decide eligibility first. Groq can phrase those verified findings in one hosted request; if unavailable, the local answer is shown.
        5. **Audit:** each chat answer can show its catalog evidence, policy sections, and executed SQL.

        **Read-only boundary:** the model has no generic SQL tool. SQLite enables `query_only` and a write-denying authorizer after pandas finishes loading. The original workbooks are never opened for writing.
        """
    )
    st.markdown(f"**Policy retrieval mode:** {assistant.policies.retrieval_mode}")
    if assistant.policies.retrieval_notice:
        st.caption(assistant.policies.retrieval_notice)
    st.caption("The optional hosted answer call receives the question, the local rule result, selected catalog evidence, and policy excerpts. The workbooks stay local and the catalog tables remain read-only.")
