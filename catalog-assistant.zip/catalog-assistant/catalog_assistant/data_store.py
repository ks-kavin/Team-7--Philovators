from __future__ import annotations

import math
import re
import sqlite3
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Any

import pandas as pd


CATALOGS = {
    "CircuitNova": "electronics_catalog.xlsx",
    "Hearthwell": "home_appliances_catalog.xlsx",
}

SHEETS = (
    "products",
    "where_we_sell",
    "product_validity",
    "price_list",
    "third_party_parts",
)

DATE_COLUMNS = {"valid_from", "valid_to", "created_on", "updated_on"}

# The app has no write workflow after pandas finishes loading the source files.
# Keep this deny-list at the SQLite boundary as a second line of defense in
# case a future tool accidentally submits a mutation statement.
_WRITE_SQLITE_ACTIONS = {
    getattr(sqlite3, name)
    for name in (
        "SQLITE_INSERT", "SQLITE_UPDATE", "SQLITE_DELETE",
        "SQLITE_CREATE_INDEX", "SQLITE_CREATE_TABLE", "SQLITE_CREATE_TRIGGER",
        "SQLITE_CREATE_VIEW", "SQLITE_CREATE_VTABLE", "SQLITE_CREATE_TEMP_INDEX", "SQLITE_CREATE_TEMP_TABLE",
        "SQLITE_CREATE_TEMP_TRIGGER", "SQLITE_CREATE_TEMP_VIEW",
        "SQLITE_DROP_INDEX", "SQLITE_DROP_TABLE", "SQLITE_DROP_TRIGGER",
        "SQLITE_DROP_VIEW", "SQLITE_DROP_VTABLE", "SQLITE_DROP_TEMP_INDEX", "SQLITE_DROP_TEMP_TABLE",
        "SQLITE_DROP_TEMP_TRIGGER", "SQLITE_DROP_TEMP_VIEW", "SQLITE_ALTER_TABLE",
        "SQLITE_REINDEX", "SQLITE_ANALYZE", "SQLITE_ATTACH", "SQLITE_DETACH",
        "SQLITE_PRAGMA", "SQLITE_TRANSACTION", "SQLITE_SAVEPOINT",
    )
    if hasattr(sqlite3, name)
}


def _read_only_authorizer(action: int, _arg1: str | None, _arg2: str | None,
                          _database: str | None, _trigger: str | None) -> int:
    if action in _WRITE_SQLITE_ACTIONS:
        return sqlite3.SQLITE_DENY
    return sqlite3.SQLITE_OK


def _is_missing(value: Any) -> bool:
    if value is None:
        return True
    try:
        return bool(pd.isna(value))
    except (TypeError, ValueError):
        return False


def normalize_excel_date(value: Any) -> str | None:
    """Convert Excel serials, pandas timestamps, or date strings to ISO dates.

    Python's date range includes the catalog's 9999-12-31 sentinel, unlike
    pandas Timestamp's narrower range.
    """
    if _is_missing(value):
        return None
    if isinstance(value, pd.Timestamp):
        return value.date().isoformat()
    if isinstance(value, datetime):
        return value.date().isoformat()
    if isinstance(value, date):
        return value.isoformat()

    if isinstance(value, (int, float)) and not isinstance(value, bool):
        if not math.isfinite(float(value)):
            return None
        try:
            return (date(1899, 12, 30) + timedelta(days=int(float(value)))).isoformat()
        except (OverflowError, ValueError):
            return None

    text = str(value).strip()
    if not text:
        return None
    if re.fullmatch(r"\d+(?:\.\d+)?", text):
        try:
            return (date(1899, 12, 30) + timedelta(days=int(float(text)))).isoformat()
        except (OverflowError, ValueError):
            return None
    try:
        return datetime.fromisoformat(text.replace("Z", "+00:00")).date().isoformat()
    except ValueError:
        try:
            parsed = pd.to_datetime(text, errors="coerce")
            return None if pd.isna(parsed) else parsed.date().isoformat()
        except (TypeError, ValueError, OverflowError):
            return None


def _prepare_frame(frame: pd.DataFrame, company: str, filename: str, sheet: str) -> pd.DataFrame:
    frame = frame.copy()
    frame.columns = [str(column).strip().lower() for column in frame.columns]
    frame.insert(0, "_company", company)
    frame.insert(1, "_source_file", filename)
    frame.insert(2, "_source_sheet", sheet)
    frame.insert(3, "_source_row", range(2, len(frame) + 2))

    for column in DATE_COLUMNS.intersection(frame.columns):
        frame[column] = frame[column].map(normalize_excel_date)

    # Convert missing values to SQL NULL while retaining mixed column types.
    frame = frame.astype(object).where(pd.notna(frame), None)
    return frame


class CatalogStore:
    """In-memory SQLite query layer populated from pandas DataFrames."""

    def __init__(self, connection: sqlite3.Connection, row_counts: dict[str, int]):
        self.connection = connection
        self.row_counts = row_counts

    @classmethod
    def from_directory(cls, data_dir: Path) -> "CatalogStore":
        catalog_dir = data_dir / "catalogs"
        connection = sqlite3.connect(":memory:", check_same_thread=False)
        connection.row_factory = sqlite3.Row
        row_counts: dict[str, int] = {}

        combined: dict[str, list[pd.DataFrame]] = {sheet: [] for sheet in SHEETS}
        for company, filename in CATALOGS.items():
            path = catalog_dir / filename
            if not path.exists():
                raise FileNotFoundError(f"Catalog file not found: {path}")
            workbook = pd.read_excel(path, sheet_name=None, engine="openpyxl", dtype=object)
            missing_sheets = set(SHEETS) - set(workbook)
            if missing_sheets:
                missing = ", ".join(sorted(missing_sheets))
                raise ValueError(f"{filename} is missing expected sheets: {missing}")

            for sheet in SHEETS:
                prepared = _prepare_frame(workbook[sheet], company, filename, sheet)
                combined[sheet].append(prepared)

        for sheet, frames in combined.items():
            table = pd.concat(frames, ignore_index=True)
            table.to_sql(sheet, connection, if_exists="replace", index=False)
            row_counts[sheet] = len(table)

        connection.executescript(
            """
            CREATE INDEX idx_products_product ON products(_company, product_id);
            CREATE INDEX idx_products_option ON products(_company, option_id);
            CREATE INDEX idx_sales_product ON where_we_sell(_company, product_id);
            CREATE INDEX idx_validity_product ON product_validity(_company, product_id);
            CREATE INDEX idx_prices_option_country ON price_list(_company, option_id, country);
            CREATE INDEX idx_parts_product ON third_party_parts(_company, linked_product_id);
            """
        )
        # Lock the loaded in-memory catalog after pandas ingestion and index
        # creation. query_only blocks data changes; the authorizer also blocks
        # attempts to turn that setting off or alter the schema.
        connection.execute("PRAGMA query_only = ON")
        connection.set_authorizer(_read_only_authorizer)
        return cls(connection, row_counts)

    def fetch_all(self, sql: str, params: tuple[Any, ...] = ()) -> list[dict[str, Any]]:
        return [dict(row) for row in self.connection.execute(sql, params).fetchall()]

    def fetch_one(self, sql: str, params: tuple[Any, ...] = ()) -> dict[str, Any] | None:
        row = self.connection.execute(sql, params).fetchone()
        return None if row is None else dict(row)

    def close(self) -> None:
        self.connection.close()
