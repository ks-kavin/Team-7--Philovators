from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path

from docx import Document
from docx.oxml.ns import qn
from docx.table import Table
from docx.text.paragraph import Paragraph


SECTION_RE = re.compile(r"^\s*(\d+(?:\.\d+)?)\.?\s+(.+?)\s*$")
TOKEN_RE = re.compile(r"[a-z0-9]+", re.IGNORECASE)
STOP_WORDS = {
    "a", "an", "and", "are", "as", "at", "be", "can", "do", "for", "from",
    "how", "i", "in", "is", "it", "may", "of", "on", "or", "our", "the",
    "to", "we", "what", "where", "which", "with",
}


@dataclass(frozen=True)
class PolicySection:
    filename: str
    title: str
    number: str
    heading: str
    text: str

    @property
    def reference(self) -> str:
        label = f"§{self.number}" if self.number else ""
        return f"{self.title} {label} {self.heading}".strip()


def _iter_document_blocks(document: Document):
    body = document.element.body
    for child in body.iterchildren():
        if child.tag == qn("w:p"):
            yield Paragraph(child, document._body)
        elif child.tag == qn("w:tbl"):
            yield Table(child, document._body)


def _table_text(table: Table) -> str:
    lines = []
    for row in table.rows:
        cells = [" ".join(cell.text.split()) for cell in row.cells]
        if any(cells):
            lines.append(" | ".join(cells))
    return "\n".join(lines)


class PolicyRetriever:
    """Small local keyword retriever for the supplied policy sections."""

    def __init__(self, sections: list[PolicySection]):
        self.sections = sections
        self.retrieval_mode = "Local keyword search"
        self.retrieval_notice = (
            None if sections else "No policy sections were extracted from the supplied documents."
        )
        self._tokens_by_section = [
            set(TOKEN_RE.findall(
                f"{section.title} {section.number} {section.heading} {section.text}".lower()
            ))
            for section in sections
        ]

    @classmethod
    def from_directory(cls, policy_dir: Path) -> "PolicyRetriever":
        sections: list[PolicySection] = []
        for path in sorted(policy_dir.glob("*.docx")):
            document = Document(path)
            title = next((p.text.strip() for p in document.paragraphs if p.text.strip()), path.stem)
            current_number = ""
            current_heading = "Overview"
            current_lines: list[str] = []

            def flush() -> None:
                content = "\n".join(line for line in current_lines if line.strip()).strip()
                if content:
                    sections.append(
                        PolicySection(
                            filename=path.name,
                            title=title,
                            number=current_number,
                            heading=current_heading,
                            text=content,
                        )
                    )

            for block in _iter_document_blocks(document):
                text = block.text.strip() if isinstance(block, Paragraph) else _table_text(block).strip()
                if not text:
                    continue
                match = SECTION_RE.match(text) if isinstance(block, Paragraph) else None
                if match:
                    flush()
                    current_number, current_heading = match.group(1), match.group(2)
                    current_lines = [text]
                else:
                    current_lines.append(text)
            flush()
        return cls(sections)

    def search(self, query: str, limit: int = 3) -> list[PolicySection]:
        if not query.strip() or limit <= 0:
            return []
        query_tokens = {
            token for token in TOKEN_RE.findall(query.lower()) if token not in STOP_WORDS
        }
        if not query_tokens:
            return []

        scored: list[tuple[int, int, PolicySection]] = []
        for index, section in enumerate(self.sections):
            overlap = query_tokens & self._tokens_by_section[index]
            score = len(overlap)
            score += sum(2 for token in overlap if token.startswith(("svc", "ec")))
            if score:
                scored.append((score, index, section))
        scored.sort(key=lambda item: (-item[0], item[2].filename, item[2].number))
        return [section for _, _, section in scored[:limit]]
