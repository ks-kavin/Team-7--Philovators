from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import date
from pathlib import Path
from typing import Any

from .data_store import CatalogStore
from .policy_retriever import PolicyRetriever, PolicySection


ID_RE = re.compile(r"\b(?:ETP|HTP|EP|EO|HP|HO|SVC)-\d{2,5}\b", re.IGNORECASE)
WRITE_INTENT_RE = re.compile(
    r"^\s*(?:(?:please\s+)?(?:can|could|would)\s+(?:you|i)\s+(?:please\s+)?|"
    r"(?:i|we)\s+(?:want|need)\s+to\s+|please\s+)?"
    r"(?:update|edit|change|delete|insert|add|remove|modify|write|save|overwrite|drop|alter)\b",
    re.IGNORECASE,
)
COUNTRY_ALIASES = {
    "germany": "DE", "german": "DE", "deutschland": "DE",
    "united states": "US", "united states of america": "US", "usa": "US", "america": "US",
    "united kingdom": "GB", "great britain": "GB", "uk": "GB", "britain": "GB",
    "france": "FR", "denmark": "DK", "netherlands": "NL", "holland": "NL",
    "india": "IN", "canada": "CA", "australia": "AU", "japan": "JP",
    "italy": "IT", "spain": "ES", "sweden": "SE", "switzerland": "CH",
    "singapore": "SG", "brazil": "BR", "mexico": "MX", "norway": "NO",
    "poland": "PL", "belgium": "BE", "austria": "AT", "ireland": "IE",
    "cuba": "CU", "iran": "IR", "north korea": "KP", "dprk": "KP",
    "syria": "SY", "russia": "RU", "belarus": "BY",
    "south korea": "KR", "the netherlands": "NL", "czech republic": "CZ",
}
COUNTRY_CODE_RE = re.compile(r"\b([A-Z]{2})\b", re.IGNORECASE)
EMBARGOED = {"CU", "IR", "KP", "SY", "RU", "BY"}
EU_COUNTRIES = {
    "AT", "BE", "BG", "HR", "CY", "CZ", "DK", "EE", "FI", "FR", "DE",
    "GR", "HU", "IE", "IT", "LV", "LT", "LU", "MT", "NL", "PL", "PT",
    "RO", "SK", "SI", "ES", "SE",
}


@dataclass
class AssistantAnswer:
    text: str
    evidence: list[dict[str, Any]] = field(default_factory=list)
    policies: list[PolicySection] = field(default_factory=list)
    queries: list[dict[str, Any]] = field(default_factory=list)
    mode: str = "local deterministic"
    notice: str | None = None
    suggestions: list[dict[str, Any]] = field(default_factory=list)


class CatalogAssistant:
    def __init__(self, store: CatalogStore, policies: PolicyRetriever):
        self.store = store
        self.policies = policies
        self._queries: list[dict[str, Any]] = []
        self.country_aliases = self._build_country_aliases()
        self.country_codes = self._load_country_codes()

    @staticmethod
    def _build_country_aliases() -> dict[str, str]:
        aliases = {name.lower(): code for name, code in COUNTRY_ALIASES.items()}
        try:
            import pycountry

            for country in pycountry.countries:
                for field_name in ("name", "common_name", "official_name"):
                    name = getattr(country, field_name, None)
                    if name:
                        aliases.setdefault(str(name).lower(), country.alpha_2)
        except ImportError:
            pass
        return aliases

    def _load_country_codes(self) -> set[str]:
        codes = set(self.country_aliases.values())
        for table, column in (
            ("price_list", "country"),
            ("where_we_sell", "quotable_countries"),
            ("where_we_sell", "serviceable_countries"),
            ("products", "quotable_countries"),
        ):
            for row in self.store.fetch_all(f"SELECT DISTINCT {column} FROM {table}"):
                value = row.get(column)
                if value:
                    codes.update(self._country_set(value))
        return codes

    def health_snapshot(self, as_of: date, record_queries: bool = False) -> dict[str, Any]:
        """Return a read-only data-quality snapshot for the demo dashboard."""
        fetch = self._run if record_queries else self.store.fetch_all
        missing_price_rows = fetch(
            """
            SELECT _company, option_id, country, region, business_unit,
                   price_status, is_npi, _source_file, _source_sheet, _source_row
            FROM price_list
            WHERE price_status = 'Cost and list price missing'
              AND is_npi = 'No'
            ORDER BY _company, region, business_unit, option_id, country
            """
        )
        npi_pending_rows = fetch(
            """
            SELECT _company, option_id, country, region, business_unit,
                   price_status, is_npi, _source_file, _source_sheet, _source_row
            FROM price_list
            WHERE price_status = 'Cost and list price missing'
              AND is_npi = 'Yes'
            ORDER BY _company, region, business_unit, option_id, country
            """
        )
        stale_price_rows = fetch(
            """
            SELECT _company, option_id, country, region, business_unit,
                   price_status, is_npi, _source_file, _source_sheet, _source_row
            FROM price_list
            WHERE price_status = 'List price not refreshed'
            ORDER BY _company, region, business_unit, option_id, country
            """
        )
        margin_candidates = fetch(
            """
            SELECT _company, option_id, country, region, business_unit,
                   currency, cost_price, list_price,
                   _source_file, _source_sheet, _source_row
            FROM price_list
            WHERE price_status = 'Available'
            ORDER BY _company, region, business_unit, option_id, country
            """
        )
        margin_violations: list[dict[str, Any]] = []
        for row in margin_candidates:
            issues: list[str] = []
            if not str(row.get("currency") or "").strip():
                issues.append("Available price has no currency")
            try:
                cost = float(row.get("cost_price"))
                list_price = float(row.get("list_price"))
            except (TypeError, ValueError):
                issues.append("Available row has a missing or invalid cost/list price")
            else:
                if cost == 0 and list_price == 0:
                    pass
                elif cost > 0 and list_price == cost:
                    issues.append("Zero-margin price requires escalation")
                elif list_price < 1.2 * cost:
                    issues.append("Price is below the 20% minimum markup")
            if issues:
                margin_violations.append(
                    self._public_row({**row, "issue": "; ".join(issues)})
                )
        expected_price_gaps = fetch(
            """
            SELECT DISTINCT s._company, s.product_id, s.option_id,
                   s.product_name, s.option_name, s._source_file,
                   s._source_sheet, s._source_row
            FROM where_we_sell AS s
            WHERE LOWER(TRIM(COALESCE(s.has_price, ''))) = 'yes'
              AND TRIM(COALESCE(s.option_id, '')) <> ''
              AND NOT EXISTS (
                  SELECT 1 FROM price_list AS p
                  WHERE p._company = s._company AND p.option_id = s.option_id
              )
            ORDER BY s._company, s.product_id, s.option_id
            """
        )
        expired_listings = fetch(
            """
            SELECT DISTINCT v._company, v.product_id, v.option_id,
                   v.valid_to AS expiry_date,
                   v._source_file AS validity_file,
                   v._source_sheet AS validity_sheet,
                   v._source_row AS validity_row,
                   s._source_file AS sales_file,
                   s._source_sheet AS sales_sheet,
                   s._source_row AS sales_row
            FROM product_validity AS v
            JOIN where_we_sell AS s
              ON s._company = v._company
             AND s.product_id = v.product_id
             AND COALESCE(s.option_id, '') = COALESCE(v.option_id, '')
            WHERE COALESCE(v.valid_to, '') <> ''
              AND v.valid_to < ?
            ORDER BY v._company, v.product_id, v.option_id
            """,
            (as_of.isoformat(),),
        )
        not_yet_valid_listings = fetch(
            """
            SELECT DISTINCT v._company, v.product_id, v.option_id,
                   v.valid_from AS start_date,
                   v._source_file AS validity_file,
                   v._source_sheet AS validity_sheet,
                   v._source_row AS validity_row,
                   s._source_file AS sales_file,
                   s._source_sheet AS sales_sheet,
                   s._source_row AS sales_row
            FROM product_validity AS v
            JOIN where_we_sell AS s
              ON s._company = v._company
             AND s.product_id = v.product_id
             AND COALESCE(s.option_id, '') = COALESCE(v.option_id, '')
            WHERE COALESCE(v.valid_from, '') <> ''
              AND v.valid_from > ?
            ORDER BY v._company, v.product_id, v.option_id
            """,
            (as_of.isoformat(),),
        )
        missing_system_records = fetch(
            """
            SELECT DISTINCT p._company, p.product_id, p.option_id,
                   'where_we_sell' AS missing_from,
                   p._source_file, p._source_sheet, p._source_row
            FROM products AS p
            WHERE NOT EXISTS (
                SELECT 1 FROM where_we_sell AS s
                WHERE s._company = p._company
                  AND s.product_id = p.product_id
                  AND COALESCE(s.option_id, '') = COALESCE(p.option_id, '')
            )
            UNION ALL
            SELECT DISTINCT p._company, p.product_id, p.option_id,
                   'product_validity' AS missing_from,
                   p._source_file, p._source_sheet, p._source_row
            FROM products AS p
            WHERE NOT EXISTS (
                SELECT 1 FROM product_validity AS v
                WHERE v._company = p._company
                  AND v.product_id = p.product_id
                  AND COALESCE(v.option_id, '') = COALESCE(p.option_id, '')
            )
            ORDER BY _company, product_id, option_id, missing_from
            """
        )
        orphan_catalog_records = fetch(
            """
            SELECT DISTINCT s._company, s.product_id, s.option_id,
                   'where_we_sell' AS source_system,
                   s._source_file, s._source_sheet, s._source_row
            FROM where_we_sell AS s
            WHERE NOT EXISTS (
                SELECT 1 FROM products AS p
                WHERE p._company = s._company
                  AND p.product_id = s.product_id
                  AND COALESCE(p.option_id, '') = COALESCE(s.option_id, '')
            )
            UNION ALL
            SELECT DISTINCT v._company, v.product_id, v.option_id,
                   'product_validity' AS source_system,
                   v._source_file, v._source_sheet, v._source_row
            FROM product_validity AS v
            WHERE NOT EXISTS (
                SELECT 1 FROM products AS p
                WHERE p._company = v._company
                  AND p.product_id = v.product_id
                  AND COALESCE(p.option_id, '') = COALESCE(v.option_id, '')
            )
            ORDER BY _company, product_id, option_id, source_system
            """
        )
        business_unit_conflicts = fetch(
            """
            SELECT DISTINCT p._company, p.product_id, p.option_id,
                   p.business_unit AS product_team_value,
                   v.business_unit AS validity_team_value,
                   p._source_file AS product_file,
                   p._source_sheet AS product_sheet,
                   p._source_row AS product_row,
                   v._source_file AS validity_file,
                   v._source_sheet AS validity_sheet,
                   v._source_row AS validity_row
            FROM products AS p
            JOIN product_validity AS v
              ON v._company = p._company
             AND v.product_id = p.product_id
             AND COALESCE(v.option_id, '') = COALESCE(p.option_id, '')
            WHERE TRIM(COALESCE(p.business_unit, '')) <> TRIM(COALESCE(v.business_unit, ''))
            ORDER BY p._company, p.product_id, p.option_id
            """
        )
        incomplete_products = fetch(
            """
            SELECT _company, product_id, option_id, product_name, business_unit,
                   export_class, country_of_origin,
                   _source_file, _source_sheet, _source_row
            FROM products
            WHERE TRIM(COALESCE(business_unit, '')) = ''
               OR TRIM(COALESCE(export_class, '')) = ''
               OR TRIM(COALESCE(country_of_origin, '')) = ''
            ORDER BY _company, product_id, option_id
            """
        )
        export_candidates = fetch(
            """
            SELECT p._company, p.product_id, p.option_id, p.export_class,
                   p.quotable_countries AS product_quotable_countries,
                   p._source_file AS product_file,
                   p._source_sheet AS product_sheet,
                   p._source_row AS product_row,
                   s.quotable_countries AS sales_quotable_countries,
                   s._source_file AS sales_file,
                   s._source_sheet AS sales_sheet,
                   s._source_row AS sales_row
            FROM products AS p
            LEFT JOIN where_we_sell AS s
              ON s._company = p._company
             AND s.product_id = p.product_id
             AND COALESCE(s.option_id, '') = COALESCE(p.option_id, '')
            WHERE UPPER(TRIM(COALESCE(p.export_class, ''))) IN ('EC-1', 'EC-2')
            ORDER BY p._company, p.product_id, p.option_id
            """
        )
        embargo_violations: list[dict[str, Any]] = []
        for row in export_candidates:
            quoted = self._country_set(row.get("product_quotable_countries"))
            quoted.update(self._country_set(row.get("sales_quotable_countries")))
            for country in sorted(quoted & EMBARGOED):
                embargo_violations.append(
                    {
                        **row,
                        "embargoed_country": country,
                    }
                )
        obsolete_parts_in_sales = fetch(
            """
            SELECT DISTINCT p._company, p.item_id, p.description,
                   p.linked_product_id, p.catalog_status,
                   p._source_file AS part_file,
                   p._source_sheet AS part_sheet,
                   p._source_row AS part_row,
                   'Yes' AS linked_product_listed
            FROM third_party_parts AS p
            WHERE UPPER(TRIM(COALESCE(p.catalog_status, ''))) = 'OBSOLETE'
              AND EXISTS (
                  SELECT 1 FROM where_we_sell AS s
                  WHERE s._company = p._company
                    AND s.product_id = p.linked_product_id
              )
            ORDER BY p._company, p.linked_product_id, p.item_id
            """
        )
        orphaned_parts = fetch(
            """
            SELECT p._company, p.item_id, p.description, p.linked_product_id,
                   p.catalog_status, p._source_file, p._source_sheet, p._source_row
            FROM third_party_parts AS p
            WHERE UPPER(TRIM(COALESCE(p.catalog_status, ''))) = 'NOT FOUND IN CATALOG'
              AND NOT EXISTS (
                  SELECT 1 FROM products AS m
                  WHERE m._company = p._company AND m.product_id = p.linked_product_id
              )
            ORDER BY p._company, p.item_id
            """
        )
        service_issues = fetch(
            """
            SELECT _company, product_id, option_id, serviceability,
                   service_plan, serviceable_countries,
                   _source_file, _source_sheet, _source_row
            FROM where_we_sell
            WHERE (UPPER(TRIM(COALESCE(serviceability, ''))) = 'SERVICEABLE'
                   AND (TRIM(COALESCE(service_plan, '')) = ''
                        OR TRIM(COALESCE(serviceable_countries, '')) = ''))
               OR (UPPER(TRIM(COALESCE(serviceability, ''))) = 'NON-SERVICEABLE'
                   AND TRIM(COALESCE(service_plan, '')) <> '')
               OR UPPER(TRIM(COALESCE(serviceability, ''))) NOT IN ('SERVICEABLE', 'NON-SERVICEABLE')
            ORDER BY _company, product_id, option_id
            """
        )
        product_rows_by_company = fetch(
            "SELECT _company, COUNT(*) AS product_rows FROM products GROUP BY _company ORDER BY _company"
        )

        missing_by_company: dict[str, int] = {}
        expired_by_company: dict[str, int] = {}
        for row in missing_price_rows:
            company = str(row.get("_company") or "Unknown")
            missing_by_company[company] = missing_by_company.get(company, 0) + 1
        for row in expired_listings:
            company = str(row.get("_company") or "Unknown")
            expired_by_company[company] = expired_by_company.get(company, 0) + 1

        return {
            "as_of": as_of.isoformat(),
            "row_counts": dict(self.store.row_counts),
            "product_rows_by_company": product_rows_by_company,
            "missing_price_rows": [self._public_row(row) for row in missing_price_rows],
            "missing_prices_by_company": missing_by_company,
            "npi_pending_rows": [self._public_row(row) for row in npi_pending_rows],
            "stale_price_rows": [self._public_row(row) for row in stale_price_rows],
            "margin_violations": margin_violations,
            "expected_price_gaps": [self._public_row(row) for row in expected_price_gaps],
            "expired_listings": expired_listings,
            "expired_listings_by_company": expired_by_company,
            "not_yet_valid_listings": not_yet_valid_listings,
            "missing_system_records": missing_system_records,
            "orphan_catalog_records": orphan_catalog_records,
            "business_unit_conflicts": business_unit_conflicts,
            "incomplete_products": [self._public_row(row) for row in incomplete_products],
            "embargo_violations": embargo_violations,
            "obsolete_parts_in_sales": obsolete_parts_in_sales,
            "orphaned_parts": orphaned_parts,
            "service_issues": service_issues,
        }

    def _catalog_audit(self, category: str, as_of: date) -> AssistantAnswer:
        snapshot = self.health_snapshot(as_of, record_queries=True)
        groups = {
            "pricing": {
                "Missing non-NPI prices": snapshot["missing_price_rows"],
                "Expected options with no price-list row": snapshot["expected_price_gaps"],
                "List prices not refreshed": snapshot["stale_price_rows"],
                "Margin or currency violations": snapshot["margin_violations"],
            },
            "lifecycle": {
                "Expired items still listed for sale": snapshot["expired_listings"],
                "Items listed before their valid-from date": snapshot["not_yet_valid_listings"],
            },
            "master_data": {
                "Products missing from a required list": snapshot["missing_system_records"],
                "Sales or validity rows missing from the product master": snapshot["orphan_catalog_records"],
                "Business-unit conflicts": snapshot["business_unit_conflicts"],
                "Products missing business unit, export class, or origin": snapshot["incomplete_products"],
            },
            "export": {
                "Controlled items listed in embargoed countries": snapshot["embargo_violations"],
            },
            "parts": {
                "Obsolete parts linked to products still listed for sale": snapshot["obsolete_parts_in_sales"],
                "Parts with missing product links": snapshot["orphaned_parts"],
            },
            "service": {
                "Service records with missing or conflicting fields": snapshot["service_issues"],
            },
        }
        category = category.strip().lower().replace("-", "_")
        selected = groups if category == "all" else {category: groups.get(category, {})}
        labels = {
            "pricing": "pricing",
            "lifecycle": "product lifecycle",
            "master_data": "master data",
            "export": "export control",
            "parts": "third-party parts",
            "service": "service",
            "all": "catalog",
        }
        evidence: list[dict[str, Any]] = []
        counts: list[tuple[str, int]] = []
        for issue_group in selected.values():
            for label, rows in issue_group.items():
                counts.append((label, len(rows)))
                evidence.extend(rows)

        found = [(label, count) for label, count in counts if count]
        if found:
            summary = "; ".join(f"{label}: {count}" for label, count in found)
            text = f"Read-only {labels.get(category, 'catalog')} audit as of {as_of.isoformat()} found {summary}."
        else:
            inspected = ", ".join(label.lower() for label, _ in counts) or "no checks"
            text = f"Read-only {labels.get(category, 'catalog')} audit as of {as_of.isoformat()} found no flagged records in: {inspected}."
        if category in {"pricing", "all"} and snapshot["npi_pending_rows"]:
            text += (
                f" {len(snapshot['npi_pending_rows'])} NPI rows with prices pending are tracked separately "
                "and are not counted as non-NPI violations."
            )

        policy_queries = {
            "pricing": "pricing policy missing price refresh margin currency",
            "lifecycle": "product lifecycle expired items still sold",
            "master_data": "data ownership source of truth business unit records",
            "export": "export control embargoed countries EC-1 EC-2",
            "parts": "third-party parts obsolete not found in catalog lifecycle",
            "service": "serviceability service plan serviceable countries",
            "all": "data ownership export control pricing product lifecycle service third-party parts",
        }
        policies = self.policies.search(policy_queries.get(category, policy_queries["all"]), 4)
        return self._answer(text, evidence[:100], policies)

    @staticmethod
    def is_write_request(question: str) -> bool:
        """Recognize direct requests to mutate catalog or policy source data."""
        return bool(WRITE_INTENT_RE.search(question))

    @classmethod
    def from_project(cls, project_root: Path) -> "CatalogAssistant":
        data_dir = project_root / "data"
        return cls(
            CatalogStore.from_directory(data_dir),
            PolicyRetriever.from_directory(data_dir / "policies-word"),
        )

    def _run(self, sql: str, params: tuple[Any, ...] = ()) -> list[dict[str, Any]]:
        self._queries.append({"sql": sql.strip(), "params": list(params)})
        return self.store.fetch_all(sql, params)

    def _answer(
        self,
        text: str,
        evidence: list[dict[str, Any]] | None = None,
        policies: list[PolicySection] | None = None,
    ) -> AssistantAnswer:
        return AssistantAnswer(
            text=text,
            evidence=[self._public_row(row) for row in (evidence or [])],
            policies=policies or [],
            queries=list(self._queries),
        )

    @staticmethod
    def _public_row(row: dict[str, Any]) -> dict[str, Any]:
        # Cost and margin inputs stay in the rule engine and are not shown to
        # the presales chat by default.
        return {key: value for key, value in row.items() if key not in {"cost_price"}}

    @staticmethod
    def _company_for_id(identifier: str) -> str | None:
        prefix = identifier.upper().split("-", 1)[0]
        if prefix in {"EP", "EO", "ETP"}:
            return "CircuitNova"
        if prefix in {"HP", "HO", "HTP"}:
            return "Hearthwell"
        return None

    @staticmethod
    def _company_from_question(question: str) -> str | None:
        lowered = question.lower()
        if "circuitnova" in lowered:
            return "CircuitNova"
        if "hearthwell" in lowered:
            return "Hearthwell"
        return None

    def _country_from_question(self, question: str) -> str | None:
        lowered = question.lower()
        for name, code in sorted(self.country_aliases.items(), key=lambda item: -len(item[0])):
            if re.search(rf"\b{re.escape(name)}\b", lowered):
                return code
        for match in COUNTRY_CODE_RE.finditer(question):
            raw_code = match.group(1)
            code = raw_code.upper()
            if code in self.country_codes:
                if raw_code.isupper():
                    return code
                # Lowercase two-letter words can be ordinary English ("us",
                # "in", "no"). Accept them as codes only in a clear country
                # slot such as "quote ... for us" or "ship to de".
                prefix = question[:match.start()]
                has_country_preposition = bool(
                    re.search(r"\b(?:in|for|to|into|within)\s+$", prefix, re.IGNORECASE)
                )
                has_destination_intent = any(
                    term in question.lower()
                    for term in ("quote", "price", "sell", "deliver", "ship", "customer")
                )
                if has_country_preposition and has_destination_intent:
                    return code
        return None

    @staticmethod
    def _country_set(value: Any) -> set[str]:
        if value is None:
            return set()
        return {part.strip().upper() for part in str(value).split(";") if part.strip()}

    def _country_name(self, code: str) -> str:
        try:
            import pycountry

            country = pycountry.countries.get(alpha_2=code)
            if country:
                return str(getattr(country, "common_name", country.name))
        except ImportError:
            pass
        return code

    @staticmethod
    def _item_key(row: dict[str, Any]) -> tuple[str, str, str]:
        return (
            str(row.get("_company") or ""),
            str(row.get("product_id") or ""),
            str(row.get("option_id") or ""),
        )

    def answer(self, question: str, as_of: date | None = None) -> AssistantAnswer:
        self._queries = []
        if self.is_write_request(question):
            return self._answer(
                "This assistant is read-only. I can identify the relevant catalog row and "
                "show its evidence for manual review, but I cannot edit or save changes "
                "to its tables or workbooks."
            )
        as_of = as_of or date.today()
        ids = [match.group(0).upper() for match in ID_RE.finditer(question)]
        service_id = next((item for item in ids if item.startswith("SVC-")), None)
        item_id = next((item for item in ids if not item.startswith("SVC-")), None)
        lowered = question.lower()

        if service_id:
            service_country = self._country_from_question(question)
            if service_country:
                return self._service_check(service_id, service_country, as_of)
            return self._service_plan(service_id)
        if item_id and self._country_from_question(question) and any(
            word in lowered for word in ("service", "service plan", "serviceability")
        ):
            return self._service_check(item_id, self._country_from_question(question), as_of)
        if item_id and item_id.startswith(("ETP-", "HTP-")):
            return self._third_party_parts(item_id)
        if item_id and any(word in lowered for word in ("part", "supplier", "obsolete", "third-party")):
            return self._third_party_parts(item_id)
        if "price" in lowered and any(word in lowered for word in ("missing", "fix", "problem")):
            return self._missing_prices(self._company_from_question(question))
        if "price" in lowered and any(word in lowered for word in ("refresh", "stale", "out of date")):
            return self._stale_prices(self._company_from_question(question))
        if "expir" in lowered and any(word in lowered for word in ("sell", "sale", "selling", "still")):
            return self._expired_still_selling(self._company_from_question(question), as_of)
        if item_id and any(word in lowered for word in ("export", "controlled", "origin", "made")):
            return self._export_status(item_id)
        if item_id and self._country_from_question(question) and any(
            word in lowered for word in ("quote", "price", "deliver", "sell", "customer")
        ):
            return self._quote_check(item_id, self._country_from_question(question), as_of)
        if item_id and "price" in lowered:
            return self._answer(
                f"I found {item_id}, but I need the destination country to check its price.",
                evidence=self._lookup_identifier(item_id),
            )
        if item_id:
            return self._product_details(item_id)

        audit_category: str | None = None
        if any(term in lowered for term in ("catalog health", "catalog audit", "audit the catalog", "data quality", "data-quality")):
            audit_category = "all"
        elif any(term in lowered for term in ("business-unit conflict", "business unit conflict", "missing from where_we_sell", "missing from product_validity", "master data gap")):
            audit_category = "master_data"
        elif any(term in lowered for term in ("embargo violation", "listed in embargo", "controlled products in", "compliance violation")):
            audit_category = "export"
        elif any(term in lowered for term in ("obsolete parts", "obsolete supplier", "orphaned part", "missing product link")):
            audit_category = "parts"
        elif any(term in lowered for term in ("serviceability issue", "missing service plan", "service record")):
            audit_category = "service"
        elif "pricing issue" in lowered or "pricing problems" in lowered:
            audit_category = "pricing"
        if audit_category:
            return self._catalog_audit(audit_category, as_of)

        policy_topics = (
            "policy", "export", "embargo", "ec-0", "ec-1", "ec-2", "price", "pricing",
            "margin", "service", "svc-", "validity", "expired", "lifecycle", "ownership",
            "owner", "source of truth", "third-party", "supplier", "obsolete", "npi", "currency",
        )
        if any(topic in lowered for topic in policy_topics):
            policies = self.policies.search(question, 3)
            if policies:
                guidance = "\n\n".join(
                    f"**{item.reference}**\n{item.text}" for item in policies
                )
                return self._answer(
                    "Relevant guidance from the supplied policy documents:\n\n" + guidance,
                    policies=policies,
                )
        return self._answer(
            "I can check product and option IDs, country quote eligibility, export class, "
            "third-party parts, service plans, pricing issues, lifecycle, and catalog health. "
            "Include an item ID or ask about one of those topics."
        )

    def _lookup_identifier(self, identifier: str) -> list[dict[str, Any]]:
        company = self._company_for_id(identifier)
        sql = """
            SELECT * FROM products
            WHERE (product_id = ? OR option_id = ?)
              AND (? IS NULL OR _company = ?)
            ORDER BY product_id, option_id
        """
        return self._run(sql, (identifier, identifier, company, company))

    def _product_details(self, identifier: str) -> AssistantAnswer:
        rows = self._lookup_identifier(identifier)
        if not rows:
            return self._answer(f"Not found: {identifier} does not appear in either supplied catalog.")

        first = rows[0]
        if first.get("option_id"):
            text = (
                f"{identifier} is option {first.get('option_name') or 'with no recorded option name'} "
                f"for {first.get('product_id')} ({first.get('product_name') or 'name not recorded'})."
            )
        else:
            options = sorted({str(row.get("option_id")) for row in rows if row.get("option_id")})
            option_text = ", ".join(options) if options else "no option IDs recorded"
            text = (
                f"{identifier} is {first.get('product_name') or 'a product with no recorded name'} "
                f"({first.get('_company')}). Recorded options: {option_text}."
            )
        return self._answer(text, rows[:30])

    def _third_party_parts(self, identifier: str) -> AssistantAnswer:
        company = self._company_for_id(identifier)
        if identifier.startswith(("ETP-", "HTP-")):
            sql = """
                SELECT p.*,
                       CASE WHEN EXISTS (
                           SELECT 1 FROM where_we_sell AS s
                           WHERE s._company = p._company
                             AND s.product_id = p.linked_product_id
                       ) THEN 'Yes' ELSE 'No' END AS linked_product_listed
                FROM third_party_parts AS p
                WHERE p.item_id = ? AND (? IS NULL OR p._company = ?)
                ORDER BY p._company, p.item_id
            """
        else:
            sql = """
                SELECT p.*,
                       CASE WHEN EXISTS (
                           SELECT 1 FROM where_we_sell AS s
                           WHERE s._company = p._company
                             AND s.product_id = p.linked_product_id
                       ) THEN 'Yes' ELSE 'No' END AS linked_product_listed
                FROM third_party_parts AS p
                WHERE p.linked_product_id = ? AND (? IS NULL OR p._company = ?)
                ORDER BY p._company, p.item_id
            """
        rows = self._run(sql, (identifier, company, company))
        if not rows:
            return self._answer(f"No third-party part records were found for {identifier}.")

        policies = self.policies.search("third-party parts obsolete at risk lifecycle policy", 2)
        details = []
        for row in rows:
            status = str(row.get("catalog_status") or "Unknown")
            line = (
                f"{row.get('item_id')}: {row.get('description') or 'description not recorded'} "
                f"({status}); origin {row.get('country_of_origin') or 'unknown'}; "
                f"distribution {row.get('distribution_countries') or 'not listed'}."
            )
            if status.lower() == "obsolete" and row.get("linked_product_listed") == "Yes":
                line += " The linked product is still listed for sale and is at risk; review before selling."
            elif status.lower() == "not found in catalog":
                line += " Purchasing should review the part-to-product link."
            details.append(line)
        return self._answer("\n\n".join(details), rows[:30], policies)

    def _export_status(self, identifier: str) -> AssistantAnswer:
        rows = self._lookup_identifier(identifier)
        if not rows:
            return self._answer(f"Not found: {identifier} does not appear in either catalog.")

        combinations = sorted(
            {
                (str(row.get("export_class") or "Unknown"), str(row.get("country_of_origin") or "Unknown"))
                for row in rows
            }
        )
        policies = self.policies.search("export control export class EC-1 EC-2 country of origin", 3)
        if len(combinations) > 1:
            details = "; ".join(f"{export_class}, origin {origin}" for export_class, origin in combinations)
            text = f"The catalog has conflicting export records for {identifier}: {details}. I can't give a single classification until the master data is reconciled."
        else:
            export_class, origin = combinations[0]
            if export_class in {"EC-1", "EC-2"}:
                text = f"Yes. {identifier} is export-controlled ({export_class}); recorded country of origin: {origin}."
                if export_class == "EC-1":
                    text += " It cannot be quoted to embargoed countries."
                else:
                    text += " It may be sold within the EU; outside the EU, sales must verify an export licence."
            elif export_class == "EC-0":
                text = f"No. {identifier} is class EC-0 and is not export-controlled. Recorded country of origin: {origin}."
            else:
                text = f"I found {identifier}, but its export class is missing or unknown, so I can't confirm whether it is controlled."
        return self._answer(text, rows[:8], policies)

    def _service_plan(self, service_id: str) -> AssistantAnswer:
        number_match = re.search(r"(\d+)$", service_id)
        number = int(number_match.group(1)) if number_match else 0
        if 1 <= number <= 6:
            tier, coverage, duration = "Basic", "replacement parts only; the customer ships the item in", "1 year"
        elif 7 <= number <= 12:
            tier, coverage, duration = "Standard", "parts and labour, with an on-site visit within 5 working days", "2 years"
        elif 13 <= number <= 18:
            tier, coverage, duration = "Premium", "parts and labour, on-site within 24 hours, plus 24/7 phone support", "3 years"
        else:
            return self._answer(f"Not found: {service_id} is outside the documented SVC-01 to SVC-18 range.")
        policies = self.policies.search(f"{service_id} service plans tier coverage duration", 3)
        return self._answer(
            f"{service_id} is the {tier} plan. It covers {coverage}. Duration: {duration}.",
            policies=policies,
        )

    def _service_check(self, identifier: str, country: str, as_of: date) -> AssistantAnswer:
        answer = self._service_check_core(identifier, country, as_of)
        if answer.text.startswith(("Yes.", "Service is listed")) or not answer.evidence:
            return answer

        candidates: set[str] = set()
        row_counts: dict[str, int] = {}
        for row in answer.evidence:
            if str(row.get("serviceability") or "").strip().lower() != "serviceable":
                continue
            if identifier.startswith("SVC-") and str(row.get("service_plan") or "").upper() != identifier:
                continue
            start = str(row.get("valid_from") or "")
            end = str(row.get("valid_to") or "")
            if not end or (start and start > as_of.isoformat()) or end < as_of.isoformat():
                continue
            for candidate in self._country_set(row.get("serviceable_countries")) - {country}:
                candidates.add(candidate)
                row_counts[candidate] = row_counts.get(candidate, 0) + 1

        verified: list[dict[str, Any]] = []
        extra_evidence: list[dict[str, Any]] = []
        for candidate in sorted(candidates, key=lambda code: (-row_counts.get(code, 0), self._country_name(code)))[:24]:
            candidate_answer = self._service_check_core(identifier, candidate, as_of)
            if candidate_answer.text.startswith(("Yes.", "Service is listed")):
                verified.append({
                    "country": candidate,
                    "country_name": self._country_name(candidate),
                    "coverage_records": row_counts.get(candidate, 0),
                })
                extra_evidence.extend(candidate_answer.evidence)

        if verified:
            verified = verified[:3]
            names = ", ".join(item["country_name"] for item in verified)
            answer.suggestions.append({
                "kind": "service_alternatives",
                "title": "Other countries with current service coverage",
                "note": "Each destination passed the serviceability and validity-date checks in the catalog.",
                "items": verified,
            })
            answer.text += f"\n\n**Other countries with current service coverage:** {names}."
            answer.evidence = (answer.evidence + extra_evidence)[:60]
            answer.queries = list(self._queries)
        return answer

    def _service_check_core(self, identifier: str, country: str, as_of: date) -> AssistantAnswer:
        company = self._company_for_id(identifier)
        if identifier.startswith("SVC-"):
            sql = """
                SELECT s._company, s.product_id, s.option_id,
                       s.serviceability, s.service_plan, s.serviceable_countries,
                       v.valid_from, v.valid_to,
                       s._source_file AS sales_file,
                       s._source_sheet AS sales_sheet,
                       s._source_row AS sales_row,
                       v._source_file AS validity_file,
                       v._source_sheet AS validity_sheet,
                       v._source_row AS validity_row
                FROM where_we_sell AS s
                LEFT JOIN product_validity AS v
                  ON v._company = s._company
                 AND v.product_id = s.product_id
                 AND COALESCE(v.option_id, '') = COALESCE(s.option_id, '')
                WHERE UPPER(TRIM(COALESCE(s.service_plan, ''))) = ?
                ORDER BY s._company, s.product_id, s.option_id
            """
            params: tuple[Any, ...] = (identifier,)
        else:
            sql = """
                SELECT s._company, s.product_id, s.option_id,
                       s.serviceability, s.service_plan, s.serviceable_countries,
                       v.valid_from, v.valid_to,
                       s._source_file AS sales_file,
                       s._source_sheet AS sales_sheet,
                       s._source_row AS sales_row,
                       v._source_file AS validity_file,
                       v._source_sheet AS validity_sheet,
                       v._source_row AS validity_row
                FROM where_we_sell AS s
                LEFT JOIN product_validity AS v
                  ON v._company = s._company
                 AND v.product_id = s.product_id
                 AND COALESCE(v.option_id, '') = COALESCE(s.option_id, '')
                WHERE (s.product_id = ? OR s.option_id = ?)
                  AND (? IS NULL OR s._company = ?)
                ORDER BY s._company, s.product_id, s.option_id
            """
            params = (identifier, identifier, company, company)

        rows = self._run(sql, params)
        if not rows:
            return self._answer(f"No service offering records were found for {identifier}.")

        eligible: list[dict[str, Any]] = []
        blockers: list[str] = []
        for row in rows:
            plan = str(row.get("service_plan") or "").strip().upper()
            if str(row.get("serviceability") or "").strip().lower() != "serviceable" or not plan:
                blockers.append(f"{row.get('product_id')} / {row.get('option_id') or 'base product'} has no serviceable plan recorded")
                continue
            if country not in self._country_set(row.get("serviceable_countries")):
                blockers.append(f"{plan} is not listed as serviceable in {country} for {row.get('product_id')} / {row.get('option_id') or 'base product'}")
                continue
            valid_from = str(row.get("valid_from") or "")
            valid_to = str(row.get("valid_to") or "")
            if not row.get("valid_to"):
                blockers.append(f"validity data is missing for {row.get('product_id')} / {row.get('option_id') or 'base product'}")
                continue
            if valid_from and valid_from > as_of.isoformat():
                blockers.append(f"{row.get('product_id')} is not valid until {valid_from}")
                continue
            if valid_to and valid_to < as_of.isoformat():
                blockers.append(f"{row.get('product_id')} expired on {valid_to}; no new service plan may be sold")
                continue
            eligible.append(row)

        policies = self.policies.search("service plan serviceable countries expired validity", 3)
        if identifier.startswith("SVC-"):
            if eligible:
                products = sorted({str(row.get("product_id")) for row in eligible})
                text = f"Yes. {identifier} is listed for service in {country} for: {', '.join(products)}."
            else:
                text = f"I found {identifier}, but no currently valid catalog listing confirms it can be sold as a service plan in {country}."
        elif eligible:
            plans = sorted({str(row.get("service_plan")) for row in eligible})
            products = sorted({str(row.get("product_id")) for row in eligible})
            text = f"Service is listed in {country} for {', '.join(products)} under {', '.join(plans)}."
        else:
            text = f"No current service offering is confirmed for {identifier} in {country}."
        if blockers:
            text += " Checks that failed or need data review: " + "; ".join(dict.fromkeys(blockers[:5])) + "."
        return self._answer(text, rows[:30], policies)

    def _missing_prices(self, company: str | None) -> AssistantAnswer:
        where = "AND _company = ?" if company else ""
        params: tuple[Any, ...] = (company,) if company else ()
        sql = f"""
            SELECT _company, option_id, country, region, business_unit,
                   price_status, is_npi, _source_file, _source_sheet, _source_row
            FROM price_list
            WHERE price_status = 'Cost and list price missing'
              AND is_npi = 'No' {where}
            ORDER BY _company, region, business_unit, option_id, country
        """
        rows = self._run(sql, params)
        counts: dict[str, int] = {}
        for row in rows:
            counts[row["_company"]] = counts.get(row["_company"], 0) + 1
        policies = self.policies.search("pricing policy missing prices non NPI violation report", 3)

        if company:
            count = counts.get(company, 0)
            text = f"{company} has {count} missing-price rows that need fixing. The count excludes NPI rows marked is_npi = Yes."
        else:
            text = "Missing-price rows that need fixing: " + "; ".join(
                f"{name}: {count}" for name, count in sorted(counts.items())
            )
        return self._answer(text, rows[:100], policies)

    def _stale_prices(self, company: str | None) -> AssistantAnswer:
        where = "AND _company = ?" if company else ""
        params: tuple[Any, ...] = (company,) if company else ()
        rows = self._run(
            f"""
            SELECT _company, option_id, country, region, business_unit,
                   price_status, is_npi, _source_file, _source_sheet, _source_row
            FROM price_list
            WHERE price_status = 'List price not refreshed' {where}
            ORDER BY _company, region, business_unit, option_id, country
            """,
            params,
        )
        policies = self.policies.search("pricing policy list prices refresh after cost update", 2)
        if company:
            text = f"{company} has {len(rows)} price rows marked List price not refreshed. They must not be quoted until pricing refreshes the list price."
        else:
            counts: dict[str, int] = {}
            for row in rows:
                owner = str(row.get("_company") or "Unknown")
                counts[owner] = counts.get(owner, 0) + 1
            summary = "; ".join(f"{owner}: {count}" for owner, count in sorted(counts.items())) or "none found"
            text = f"Price rows marked List price not refreshed: {summary}. These rows must not be quoted until pricing refreshes the list price."
        return self._answer(text, rows[:100], policies)

    def _expired_still_selling(self, company: str | None, as_of: date) -> AssistantAnswer:
        where = "AND v._company = ?" if company else ""
        params: tuple[Any, ...] = (as_of.isoformat(), company) if company else (as_of.isoformat(),)
        sql = f"""
            SELECT DISTINCT v._company, v.product_id, v.option_id,
                   v.valid_to AS expiry_date,
                   v._source_file AS validity_file,
                   v._source_sheet AS validity_sheet,
                   v._source_row AS validity_row,
                   s._source_file AS sales_file,
                   s._source_sheet AS sales_sheet,
                   s._source_row AS sales_row
            FROM product_validity AS v
            JOIN where_we_sell AS s
              ON s._company = v._company
             AND s.product_id = v.product_id
             AND COALESCE(s.option_id, '') = COALESCE(v.option_id, '')
            WHERE COALESCE(v.valid_to, '') <> ''
              AND v.valid_to < ? {where}
            ORDER BY v._company, v.product_id, v.option_id
        """
        rows = self._run(sql, params)
        product_ids = sorted({(row["_company"], row["product_id"]) for row in rows})
        policies = self.policies.search("product lifecycle expired items must not be sold valid_to", 3)
        if company:
            names = [product_id for owner, product_id in product_ids if owner == company]
            text = f"As of {as_of.isoformat()}, {len(names)} {company} products are expired but still listed for sale."
            if names:
                text += " Product IDs: " + ", ".join(names) + "."
        else:
            count_by_company: dict[str, set[str]] = {}
            for owner, product_id in product_ids:
                count_by_company.setdefault(owner, set()).add(product_id)
            summary = "; ".join(
                f"{owner}: {len(names)}" for owner, names in sorted(count_by_company.items())
            ) or "none found"
            text = f"As of {as_of.isoformat()}, expired products still listed for sale: {summary}."
        return self._answer(text, rows[:100], policies)

    def _quote_check(self, identifier: str, country: str, as_of: date) -> AssistantAnswer:
        answer = self._quote_check_core(identifier, country, as_of)
        if (answer.text.startswith("Yes.") and "list price" in answer.text) or not answer.evidence:
            return answer

        company = self._company_for_id(identifier)
        if identifier.upper().startswith(("EO-", "HO-")):
            sales_rows = self._run(
                "SELECT * FROM where_we_sell WHERE _company = ? AND option_id = ? ORDER BY product_id, option_id",
                (company, identifier),
            )
        else:
            sales_rows = self._run(
                "SELECT * FROM where_we_sell WHERE _company = ? AND product_id = ? ORDER BY product_id, option_id",
                (company, identifier),
            )

        sales_candidates = set().union(*(self._country_set(row.get("quotable_countries")) for row in sales_rows)) if sales_rows else set()
        sales_candidates.discard(country)
        option_ids = sorted({str(row.get("option_id") or "").strip() for row in sales_rows if row.get("option_id")})
        requested_regions: set[str] = set()
        if option_ids:
            placeholders = ", ".join("?" for _ in option_ids)
            region_rows = self._run(
                f"SELECT DISTINCT region FROM price_list WHERE _company = ? AND country = ? AND option_id IN ({placeholders})",
                (company, country, *option_ids),
            )
            requested_regions = {
                str(row.get("region") or "").strip()
                for row in region_rows
                if str(row.get("region") or "").strip()
            }
            price_country_rows = self._run(
                f"""SELECT DISTINCT country FROM price_list
                    WHERE _company = ? AND option_id IN ({placeholders})
                      AND TRIM(COALESCE(price_status, '')) = 'Available'
                      AND TRIM(COALESCE(currency, '')) <> ''
                      AND list_price IS NOT NULL""",
                (company, *option_ids),
            )
            countries_with_available_prices = {
                str(row.get("country") or "").strip().upper()
                for row in price_country_rows
                if str(row.get("country") or "").strip()
            }
        else:
            countries_with_available_prices = set()
        candidates = sales_candidates & countries_with_available_prices

        verified_by_country_currency: dict[tuple[str, str], dict[str, Any]] = {}
        extra_evidence: list[dict[str, Any]] = []
        alternative_failures: list[str] = []
        for candidate in sorted(candidates, key=self._country_name):
            candidate_answer = self._quote_check_core(identifier, candidate, as_of)
            extra_evidence.extend(candidate_answer.evidence)
            price_rows = [
                row for row in candidate_answer.evidence
                if row.get("price_status") == "Available"
                and row.get("list_price") is not None
                and str(row.get("currency") or "").strip()
            ]
            if not candidate_answer.text.startswith("Yes.") or not price_rows:
                alternative_failures.append(
                    f"{self._country_name(candidate)}: {candidate_answer.text}"
                )
                continue
            for price in price_rows:
                try:
                    numeric_price = float(price["list_price"])
                except (TypeError, ValueError):
                    continue
                alternative = {
                    "country": candidate,
                    "country_name": self._country_name(candidate),
                    "option_id": str(price.get("option_id") or ""),
                    "currency": str(price["currency"]).strip(),
                    "list_price": numeric_price,
                    "region": str(price.get("region") or "").strip(),
                    "same_catalog_region": str(price.get("region") or "").strip() in requested_regions
                    and bool(requested_regions),
                    "requested_region_recorded": bool(requested_regions),
                }
                group_key = (candidate, alternative["currency"])
                existing = verified_by_country_currency.get(group_key)
                if existing is None or alternative["list_price"] > existing["list_price"]:
                    verified_by_country_currency[group_key] = alternative

        # Prices in different currencies cannot be ranked against each other.
        by_currency: dict[str, list[dict[str, Any]]] = {}
        for item in verified_by_country_currency.values():
            by_currency.setdefault(item["currency"], []).append(item)
        top_alternatives: list[dict[str, Any]] = []
        for currency, items in sorted(by_currency.items()):
            items.sort(key=lambda item: (
                not item["same_catalog_region"], -item["list_price"], item["country_name"]
            ))
            top_alternatives.extend(items[:3])

        if top_alternatives:
            currency_groups = sorted({item["currency"] for item in top_alternatives})
            region_note = (
                "Same catalog-region destinations appear first when the requested market has a region recorded. "
                if requested_regions else "No requested-market region was recorded, so geographic proximity cannot be inferred. "
            )
            currency_note = region_note + (
                "Alternatives are ranked by listed price within each currency; different currencies are not comparable."
                if len(currency_groups) > 1
                else f"These destinations passed the same sales, export-control, validity, and available-price checks; ranked by listed {currency_groups[0]} price after the region preference."
            )
            answer.suggestions.append({
                "kind": "quote_alternatives",
                "title": "Quote-ready alternative destinations",
                "note": currency_note,
                "items": top_alternatives,
            })
            answer.text += "\n\n**Quote-ready alternatives by listed price:** " + "; ".join(
                f"{item['country_name']} — {item['currency']} {item['list_price']:,.2f}"
                + (" (same catalog region)" if item["same_catalog_region"] else "")
                for item in top_alternatives
            ) + "."
            answer.evidence = (answer.evidence + extra_evidence)[:80]
            answer.queries = list(self._queries)
        else:
            if not sales_candidates:
                note = "The sales sheet lists no other quotable destination for this item."
            elif not candidates:
                note = "Other destinations are listed for sale, but none has an available price-list row for this item."
            else:
                reasons = list(dict.fromkeys(alternative_failures))[:3]
                note = "No other destination passed all quote checks. " + " ".join(reasons)
            answer.suggestions.append({
                "kind": "no_quote_alternatives",
                "title": "No quote-ready alternatives found",
                "note": note,
                "items": [],
            })
            answer.text += f"\n\n**Alternative check:** {note}"
            answer.evidence = (answer.evidence + extra_evidence)[:80]
            answer.queries = list(self._queries)
        return answer

    def _quote_check_core(self, identifier: str, country: str, as_of: date) -> AssistantAnswer:
        items = self._lookup_identifier(identifier)
        if not items:
            return self._answer(
                f"Not found: {identifier} does not appear in either supplied catalog, so I can't confirm a {country} price."
            )

        company = self._company_for_id(identifier)
        if identifier.upper().startswith(("EO-", "HO-")):
            sales_sql = """
                SELECT * FROM where_we_sell
                WHERE _company = ? AND option_id = ?
                ORDER BY product_id, option_id
            """
            sales_rows = self._run(sales_sql, (company, identifier))
        else:
            sales_sql = """
                SELECT * FROM where_we_sell
                WHERE _company = ? AND product_id = ?
                ORDER BY product_id, option_id
            """
            sales_rows = self._run(sales_sql, (company, identifier))

        offered_rows = [
            row for row in sales_rows
            if country in self._country_set(row.get("quotable_countries"))
        ]
        if not offered_rows:
            policies = self.policies.search("where we sell quotable countries sales availability", 3)
            evidence = items[:8] + sales_rows[:8]
            return self._answer(
                f"No. I found {identifier}, but the sales catalog does not list it as quotable in {country}.",
                evidence,
                policies,
            )

        blockers: list[str] = []
        evidence: list[dict[str, Any]] = []
        used_policy_queries: list[str] = []
        seen_items: set[tuple[str, str, str]] = set()

        for sale in offered_rows:
            key = self._item_key(sale)
            if key in seen_items:
                continue
            seen_items.add(key)
            evidence.append(sale)
            product_row = next(
                (
                    row for row in items
                    if row.get("product_id") == sale.get("product_id")
                    and str(row.get("option_id") or "") == str(sale.get("option_id") or "")
                ),
                items[0],
            )
            evidence.append(product_row)

            validity_sql = """
                SELECT * FROM product_validity
                WHERE _company = ? AND product_id = ?
                  AND COALESCE(option_id, '') = COALESCE(?, '')
                ORDER BY valid_to
            """
            validity_rows = self._run(
                validity_sql,
                (company, sale.get("product_id"), sale.get("option_id")),
            )
            evidence.extend(validity_rows[:2])
            if not validity_rows:
                blockers.append(f"validity data is missing for {sale.get('product_id')} / {sale.get('option_id') or 'base product'}")
                used_policy_queries.append("product lifecycle validity")
            else:
                for validity in validity_rows:
                    expiry = str(validity.get("valid_to") or "")
                    start = str(validity.get("valid_from") or "")
                    if expiry and expiry < as_of.isoformat():
                        blockers.append(f"{sale.get('product_id')} expired on {expiry}")
                        used_policy_queries.append("product lifecycle expired")
                        break
                    if start and start > as_of.isoformat():
                        blockers.append(f"{sale.get('product_id')} is not valid until {start}")
                        used_policy_queries.append("product lifecycle valid from")
                        break

            export_class = str(product_row.get("export_class") or "").upper()
            if export_class in {"EC-1", "EC-2"} and country in EMBARGOED:
                blockers.append(f"{export_class} items cannot be quoted in embargoed country {country}")
                used_policy_queries.append("export control embargoed countries")
            elif export_class == "EC-2" and country not in EU_COUNTRIES:
                blockers.append(f"{country} requires a verified export licence for EC-2")
                used_policy_queries.append("export control EC-2 export licence EU")
            elif export_class not in {"EC-0", "EC-1", "EC-2"}:
                blockers.append(f"export class is missing or unknown for {sale.get('product_id')}")
                used_policy_queries.append("export control export class")

            has_price = str(sale.get("has_price") or "").strip().lower() == "yes"
            option_id = str(sale.get("option_id") or "").strip()
            if has_price and option_id:
                price_sql = """
                    SELECT * FROM price_list
                    WHERE _company = ? AND option_id = ? AND country = ?
                    ORDER BY _source_row
                """
                price_rows = self._run(price_sql, (company, option_id, country))
                evidence.extend(price_rows[:3])
                if not price_rows:
                    blockers.append(f"there is no {country} price-list row for {option_id}")
                    used_policy_queries.append("pricing policy price row missing")
                else:
                    for price in price_rows:
                        status = str(price.get("price_status") or "").strip()
                        npi = str(price.get("is_npi") or "").strip().lower() == "yes"
                        if status == "Cost and list price missing":
                            label = "NPI price pending" if npi else "cost and list price missing"
                            blockers.append(f"{option_id} in {country}: {label}")
                            used_policy_queries.append("pricing policy missing NPI price")
                        elif status == "List price not refreshed":
                            blockers.append(f"{option_id} in {country}: list price needs refreshing")
                            used_policy_queries.append("pricing policy list price refresh")
                        elif status != "Available":
                            blockers.append(f"{option_id} in {country}: price status is {status or 'unknown'}")
                            used_policy_queries.append("pricing policy available price")
                        else:
                            currency = str(price.get("currency") or "").strip()
                            if not currency:
                                blockers.append(f"{option_id} in {country}: currency is missing")
                                used_policy_queries.append("pricing policy currency")
                            try:
                                cost = float(price.get("cost_price"))
                                list_price = float(price.get("list_price"))
                            except (TypeError, ValueError):
                                blockers.append(f"{option_id} in {country}: cost or list price is missing")
                                used_policy_queries.append("pricing policy missing cost or list price")
                            else:
                                if not (cost == 0 and list_price == 0) and list_price < 1.2 * cost:
                                    if cost > 0 and list_price == cost:
                                        blockers.append(f"{option_id} in {country}: zero-margin price requires escalation")
                                    else:
                                        blockers.append(f"{option_id} in {country}: price is below the 20% minimum markup")
                                    used_policy_queries.append("pricing policy minimum margin")
            elif has_price:
                blockers.append(f"{sale.get('product_id')} has no option ID to match to a price")
                used_policy_queries.append("pricing policy price row missing")

        blockers = list(dict.fromkeys(blockers))
        policies: list[PolicySection] = []
        for policy_query in dict.fromkeys(used_policy_queries):
            policies.extend(self.policies.search(policy_query, 1))
        # Deduplicate the policy sections while preserving retrieval order.
        policies = list({(item.filename, item.number): item for item in reversed(policies)}.values())

        if blockers:
            text = f"No. {identifier} is listed for sale in {country}, but it is not ready to quote: " + "; ".join(blockers) + "."
        elif all(str(row.get("has_price") or "").strip().lower() != "yes" for row in offered_rows):
            text = f"{identifier} is listed for sale in {country}, and the sales sheet says no separate price is expected. Confirm the parent-product quote context before presenting a customer price."
        else:
            price = next(
                (row for row in reversed(evidence) if row.get("price_status") == "Available"),
                None,
            )
            if price:
                text = f"Yes. {identifier} passes the catalog checks for {country}: {price.get('currency')} {price.get('list_price')} list price."
            else:
                text = f"Yes. {identifier} passes the catalog checks for {country}."
        if not policies:
            policies = self.policies.search("quote price lifecycle export", 3)
        return self._answer(text, evidence[:40], policies)
