# Catalog Assistant for Presales

A read-only hackathon MVP for the fictional CircuitNova and Hearthwell catalogs. It combines exact pandas/SQLite lookups with policy retrieval and optional hosted answer generation.

## Run on Windows

Open PowerShell in this folder. If your virtual environment is in the parent `C:\philips-hackathon` folder, update it and launch the app with:

```powershell
& ..\.venv\Scripts\python.exe -m pip install -r requirements.txt
& ..\.venv\Scripts\python.exe -m streamlit run app.py
```

Or create a project-local environment:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
streamlit run app.py
```

## Configure Groq

Catalog and policy retrieval run locally. Groq is used for one optional answer phrasing call after the Python rules have already checked the catalog and retrieved the relevant policy sections. No Google embedding key or LangChain package is needed.

```powershell
$env:LLM_PROVIDER = "groq"
$env:GROQ_API_KEY = "your-groq-key"
$env:GROQ_MODEL = "openai/gpt-oss-20b"
& ..\.venv\Scripts\python.exe -m streamlit run app.py
```

Keep keys in environment variables or an approved secret store. Do not paste keys into source files or chat. With Groq enabled, the question, local answer, selected catalog evidence, and relevant policy excerpts are sent to Groq once. The original workbooks stay local and are never edited. OpenRouter is also supported by setting `LLM_PROVIDER=openrouter`, `OPENROUTER_API_KEY`, and `OPENROUTER_MODEL`.

Without a hosted key, the local deterministic answer is shown. If Groq is unavailable, the app falls back to those same local results.

## What the MVP does

- Loads all five sheets from both workbooks with pandas and keeps source file, sheet, and Excel row metadata.
- Converts Excel dates to ISO format, including the `9999-12-31` open-ended validity sentinel.
- Uses in-memory SQLite for parameterized, auditable product, option, price, quote, lifecycle, and supplier-part queries.
- Extracts numbered sections and tables from the five Word policies and ranks them with a fast local keyword search.
- Uses deterministic Python rules for quote checks and catalog-health calculations. The optional language model receives already-checked findings and cannot select tools or execute SQL.
- When a destination is blocked or has no usable quote, checks other catalog-listed countries and displays up to three quote-ready alternatives per currency, ranked by list price only after export, validity, sale coverage, and price checks pass. Service queries can also show other countries with current service coverage.
- Provides a catalog-health dashboard for non-NPI missing prices, NPI pending-price rows, expected price-list gaps, stale prices, margin/currency violations, expired listings, master-data gaps, business-unit conflicts, missing export fields, embargoed listings, obsolete/orphaned supplier parts, and service-record issues.
- Shows answer mode, source evidence, policy sections, and executed SQL in the chat interface.
- Downloads a Markdown answer log with demo answers, suggested alternatives, policy references, and catalog source-row references.
- Refuses direct requests to edit catalog or policy data.

## Read-only boundary

Pandas reads the source workbooks; it never opens them for writing. After ingestion and index creation, SQLite enables `PRAGMA query_only` and a SQLite authorizer denies data changes, schema changes, attachments, and PRAGMA changes. The model has no SQL or catalog tools. The local Python rules call fixed functions that run parameterized `SELECT` statements before the optional model request.

## Retrieval design

This is a grounded hybrid assistant, not a traditional vector-only RAG flow:

1. **Catalog facts:** deterministic rules and parameterized SQL check exact IDs, prices, validity, country eligibility, and cross-sheet consistency.
2. **Policy text:** numbered policy sections are ranked locally with keyword matching. This small document set does not need a remote embedding call for the MVP.
3. **Answer generation:** Groq can phrase the already-checked result in one request. Without Groq, the local deterministic answer is used. The UI retains source evidence, policy sections, and executed SQL for review.

Product and price facts stay in relational queries. The assistant does not let the model generate SQL or make the compliance decision.

## Catalog checks

- **Quote eligibility:** country sales coverage, validity dates, export class, price-row presence, price status, currency, and the minimum price rule are checked before a price is presented.
- **Pricing:** non-NPI rows with missing prices, options marked as requiring a price but missing any price-list row, unrefreshed list prices, minimum-markup/currency violations, and NPI pending-price rows are surfaced separately. NPI pending-price rows are excluded from the non-NPI violation count.
- **Lifecycle:** expired products and products listed before their `valid_from` date are reported using the selected evaluation date.
- **Master data:** product rows missing from required systems, sales/validity rows without a product-master match, business-unit disagreements, and missing business-unit/export/origin fields are shown with source rows.
- **Export control:** controlled items listed for embargoed countries are flagged; EC-2 quotes outside the EU require a verified licence, which the supplied catalog does not record.
- **Supplier parts:** obsolete parts linked to products still listed for sale and parts with missing product links are flagged.
- **Service:** serviceable rows missing a plan or serviceable countries, and non-serviceable rows with a plan, are flagged.

## Demo flow

1. Open **Catalog health** to show that the workbooks loaded and review flagged rows.
2. Ask a sample question from the sidebar.
3. Open the answer's catalog evidence, policy evidence, and executed SQL panels.
4. Change the evaluation date and re-ask an expiry or quote question to demonstrate date-sensitive checks.
5. Ask the assistant to update a price or table to demonstrate the read-only refusal.

## Project structure

```text
app.py
catalog_assistant/
  assistant.py
  data_store.py
  llm_agent.py
  policy_retriever.py
data/
  catalogs/
  policies-word/
  README.md
  sample-questions.md
```

The supplied data and policies are fictional. This MVP uses the provided rules and does not connect to live product systems, validate live export licences, or write approved corrections back to a source system.
