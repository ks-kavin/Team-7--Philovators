
import { useEffect, useState } from "react";
import "./App.css";

type MonthlyData = Record<string, number[]>;
type YearlyData = Record<string, number>;

type SimulationData = {
  monthly: MonthlyData;
  yearly: YearlyData;
};

type Sliders = {
  marketing_spend: number;
  arpu: number;
  ctc_per_head: number;
};

const MONTHS = [
  "Apr", "May", "Jun", "Jul", "Aug", "Sep",
  "Oct", "Nov", "Dec", "Jan", "Feb", "Mar",
];

const KPI_LABELS: Record<string, string> = {
  marketing_spend: "Marketing Spend",
  cac: "Customer Acquisition Cost (CAC)",
  arpu: "Average Revenue per User (ARPU)",
  churn_pct: "Churn %",
  billable_heads: "Billable Employees",
  nonbillable_heads: "Non-billable Employees",
  utilization_pct: "Utilization %",
  rate_per_hour: "Rate per Hour",
  ctc_per_head: "CTC per Employee",
  hosting_per_sub: "Hosting Cost per Subscriber",
  new_subscribers: "New Subscribers",
  churned_subscribers: "Churned Subscribers",
  closing_subscribers: "Closing Subscribers",
  product_revenue: "Product Revenue",
  billable_hours: "Billable Hours",
  service_revenue: "Service Revenue",
  total_revenue: "Total Revenue",
  total_heads: "Total Employees",
  salaries: "Salaries",
  hosting: "Hosting Expenses",
  gateway_fees: "Gateway Fees",
  rent_utilities: "Rent & Utilities",
  total_expenses: "Total Expenses",
  profit_before_tax: "Profit Before Tax",
  tax: "Tax",
  net_profit: "Net Profit",
  net_margin_pct: "Net Profit Margin %",
};

function formatNumber(value: number | undefined) {
  if (value === undefined || !Number.isFinite(value)) return "—";

  return value.toLocaleString("en-US", {
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  });
}

function formatMoney(value: number | undefined) {
  if (value === undefined || !Number.isFinite(value)) return "—";

  return `$${value.toLocaleString("en-US", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}K`;
}

function getKpiLabel(key: string) {
  return KPI_LABELS[key] ??
    key.replaceAll("_", " ").replace(/\b\w/g, (letter) =>
      letter.toUpperCase()
    );
}

function App() {
  const [baseline, setBaseline] = useState<SimulationData | null>(null);
  const [scenario, setScenario] = useState<SimulationData | null>(null);

  const [sliders, setSliders] = useState<Sliders>({
    marketing_spend: 0,
    arpu: 0,
    ctc_per_head: 0,
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [status, setStatus] = useState("Loading baseline...");

  useEffect(() => {
    fetch("http://localhost:8000/api/baseline")
      .then((response) => {
        if (!response.ok) {
          throw new Error("Could not load baseline");
        }
        return response.json();
      })
      .then((result: SimulationData) => {
        setBaseline(result);
        setStatus("Baseline loaded");
      })
      .catch(() => {
        setError("Backend connection failed. Please start the backend.");
        setStatus("Connection error");
      });
  }, []);

  const updateSlider = (key: keyof Sliders, value: number) => {
    setSliders((previous) => ({
      ...previous,
      [key]: value,
    }));
  };

  const runSimulation = async () => {
    setLoading(true);
    setError("");

    try {
      const response = await fetch("http://localhost:8000/api/scenario", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(sliders),
      });

      if (!response.ok) {
        throw new Error("Scenario request failed");
      }

      const result: SimulationData = await response.json();

      setScenario(result);
      setStatus("Scenario calculated");
    } catch {
      setError("Scenario calculation failed. Please try again.");
      setStatus("Calculation error");
    } finally {
      setLoading(false);
    }
  };

  const resetScenario = () => {
    setSliders({
      marketing_spend: 0,
      arpu: 0,
      ctc_per_head: 0,
    });

    setScenario(null);
    setError("");
    setStatus("Baseline loaded");
  };

  if (!baseline) {
    return (
      <div className="dashboard">
        <h2>{error || "Loading dashboard..."}</h2>
      </div>
    );
  }

  const displayedData = scenario ?? baseline;
  const yearly = displayedData.yearly;
  const baselineYearly = baseline.yearly;

  const netProfit = yearly.net_profit;
  const revenue = yearly.total_revenue;
  const expenses = yearly.total_expenses;
  const subscribers = yearly.closing_subscribers;

  const profitDifference =
    netProfit - baselineYearly.net_profit;

  const revenueDifference =
    revenue - baselineYearly.total_revenue;

  const expensesDifference =
    expenses - baselineYearly.total_expenses;

  const subscriberDifference =
    subscribers - baselineYearly.closing_subscribers;

  const monthlyPbt = displayedData.monthly.profit_before_tax ?? [];
  const monthlyUtilization =
    displayedData.monthly.utilization_pct ?? [];

  const minimumMonthlyPbt = Math.min(...monthlyPbt);
  const maximumUtilization = Math.max(...monthlyUtilization);

  const guardrails = [
    {
      label: "FY net margin ≥ 10%",
      passed: (yearly.net_margin_pct ?? 0) >= 10,
      value: `${formatNumber(yearly.net_margin_pct)}%`,
    },
    {
      label: "No monthly PBT loss",
      passed: minimumMonthlyPbt >= 0,
      value: formatMoney(minimumMonthlyPbt),
    },
    {
      label: "March subscribers ≥ 3,900",
      passed: subscribers >= 3900,
      value: formatNumber(subscribers),
    },
    {
      label: "Utilization ≤ 85%",
      passed: maximumUtilization <= 85,
      value: `${formatNumber(maximumUtilization)}%`,
    },
  ];

  const kpiKeys = Object.keys(displayedData.monthly);

  return (
    <div className="dashboard">
      <header className="header">
        <div>
          <p className="eyebrow">FINANCIAL PLANNING</p>
          <h1>Profit What-If Simulator</h1>
          <p className="subtitle">
            Explore business decisions and understand their impact on profit.
          </p>
        </div>

        <div className="status">
          <span className="status-dot" />
          {status}
        </div>
      </header>

      {error && <p className="error-message">{error}</p>}

      {/* Main KPI cards */}
      <section className="kpi-grid">
        <div className="kpi-card">
          <p>Net Profit</p>
          <h2>{formatMoney(netProfit)}</h2>
          <span className="kpi-note">
            {scenario
              ? `${formatMoney(profitDifference)} vs baseline`
              : "FY baseline"}
          </span>
        </div>

        <div className="kpi-card">
          <p>Total Revenue</p>
          <h2>{formatMoney(revenue)}</h2>
          <span className="kpi-note">
            {scenario
              ? `${formatMoney(revenueDifference)} vs baseline`
              : "FY baseline"}
          </span>
        </div>

        <div className="kpi-card">
          <p>Total Expenses</p>
          <h2>{formatMoney(expenses)}</h2>
          <span className="kpi-note">
            {scenario
              ? `${formatMoney(expensesDifference)} vs baseline`
              : "FY baseline"}
          </span>
        </div>

        <div className="kpi-card">
          <p>Subscribers</p>
          <h2>{formatNumber(subscribers)}</h2>
          <span className="kpi-note">
            {scenario
              ? `${formatNumber(subscriberDifference)} vs baseline`
              : "March closing"}
          </span>
        </div>
      </section>

      {/* Scenario controls and results */}
      <section className="workspace">
        <div className="panel">
          <div className="panel-heading">
            <div>
              <p className="eyebrow">SCENARIO CONTROLS</p>
              <h2>Business decisions</h2>
            </div>
          </div>

          <p className="panel-description">
            Adjust the sliders and run a simulation to see the financial impact.
          </p>

          <div className="slider-control">
            <label>
              Marketing spend: {sliders.marketing_spend * 100}%
            </label>
            <input
              type="range"
              min="-50"
              max="50"
              step="1"
              value={sliders.marketing_spend * 100}
              onChange={(event) =>
                updateSlider(
                  "marketing_spend",
                  Number(event.target.value) / 100
                )
              }
            />
          </div>

          <div className="slider-control">
            <label>
              Subscription price: {sliders.arpu * 100}%
            </label>
            <input
              type="range"
              min="-20"
              max="20"
              step="1"
              value={sliders.arpu * 100}
              onChange={(event) =>
                updateSlider("arpu", Number(event.target.value) / 100)
              }
            />
          </div>

          <div className="slider-control">
            <label>
              Salary raise: {sliders.ctc_per_head * 100}%
            </label>
            <input
              type="range"
              min="0"
              max="20"
              step="1"
              value={sliders.ctc_per_head * 100}
              onChange={(event) =>
                updateSlider(
                  "ctc_per_head",
                  Number(event.target.value) / 100
                )
              }
            />
          </div>

          <button
            className="primary-button"
            onClick={runSimulation}
            disabled={loading}
          >
            {loading ? "Calculating..." : "Run simulation"}
          </button>

          <button className="reset-button" onClick={resetScenario}>
            Reset scenario
          </button>
        </div>

        <div className="panel results-panel">
          <p className="eyebrow">SIMULATION RESULTS</p>
          <h2>Scenario results</h2>

          <h3>Scenario Net Profit</h3>
          <h2>{formatMoney(netProfit)}</h2>

          <p>Revenue: {formatMoney(revenue)}</p>
          <p>Expenses: {formatMoney(expenses)}</p>
          <p>March subscribers: {formatNumber(subscribers)}</p>

          <h3>Guardrail checks</h3>

          <p>
            {guardrails.every((item) => item.passed)
              ? "All guardrails passed"
              : "Some guardrails need attention"}
          </p>

          {guardrails.map((item) => (
            <div className="guardrail-row" key={item.label}>
              <span>{item.label}</span>
              <strong
                style={{
                  color: item.passed ? "green" : "red",
                }}
              >
                {item.passed ? "PASS" : "FAIL"} · {item.value}
              </strong>
            </div>
          ))}
        </div>
      </section>

      {/* Complete KPI table */}
      <section className="panel kpi-table-panel">
        <p className="eyebrow">FINANCIAL BREAKDOWN</p>
        <h2>All KPI values</h2>
        <p className="panel-description">
          Monthly values from April to March, with financial-year values and
          baseline comparison.
        </p>

        <div className="table-scroll">
          <table className="kpi-table">
            <thead>
              <tr>
                <th>KPI</th>
                {MONTHS.map((month) => (
                  <th key={month}>{month}</th>
                ))}
                <th>FY Value</th>
                <th>Baseline FY</th>
              </tr>
            </thead>

            <tbody>
              {kpiKeys.map((key) => {
                const monthlyValues = displayedData.monthly[key] ?? [];
                const yearlyValue = displayedData.yearly[key];
                const baselineValue = baseline.yearly[key];

                return (
                  <tr key={key}>
                    <td className="kpi-name">
                      {getKpiLabel(key)}
                    </td>

                    {MONTHS.map((month, index) => (
                      <td key={`${key}-${month}`}>
                        {formatNumber(monthlyValues[index])}
                      </td>
                    ))}

                    <td className="fy-value">
                      {formatNumber(yearlyValue)}
                    </td>

                    <td>
                      {formatNumber(baselineValue)}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}

export default App;
