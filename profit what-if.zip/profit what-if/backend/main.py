
from fastapi import FastAPI, Body
from fastapi.middleware.cors import CORSMiddleware

from scenario_eng import calculate_baseline, calculate_scenario

app = FastAPI(title="Profit What-If Simulator")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/")
def home():
    return {"message": "Profit Simulator API is running"}


@app.get("/api/baseline")
def baseline():
    return calculate_baseline()


@app.post("/api/scenario")
def scenario(sliders: dict[str, float] = Body(...)):
    return calculate_scenario(sliders)
