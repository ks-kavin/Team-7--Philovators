import json
import math
from pathlib import Path

DATA_FILE = Path(__file__).parent / "company-data.json"


def load_data():
    with open(DATA_FILE, "r", encoding="utf-8") as file:
        return json.load(file)


def round_half_up(value):
    """Round halves away from zero."""
    if value >= 0:
        return math.floor(value + 0.5)
    return math.ceil(value - 0.5)


def calculate_scenario(sliders=None):
    data = load_data()
    kpis = data["kpis"]
    sliders = sliders or {}

    definitions = {kpi["id"]: kpi for kpi in kpis}
    monthly = {kpi["id"]: [] for kpi in kpis}

    # Load input KPI actual values.
    inputs = {}

    for kpi in kpis:
        if kpi.get("kind") != "input":
            continue

        kpi_id = kpi["id"]
        actuals = kpi["actuals"]
        values = actuals.copy()

        # Apply slider only to KPIs marked as levers.
        change = sliders.get(kpi_id, 0)

        if change and kpi.get("lever"):
            start_month = kpi.get("effectiveFromMonth", 1)

            for month_index in range(start_month - 1, 12):
                values[month_index] *= (1 + change)

        inputs[kpi_id] = values

    # Apply scenario reactions, such as marketing spend -> CAC.
    for reaction in data["scenarioRules"].get("reactsTo", []):
        source_id = reaction["source"]
        target_id = reaction["target"]
        elasticity = reaction["elasticity"]

        source_actual = definitions[source_id]["actuals"]
        source_scenario = inputs[source_id]
        target_actual = definitions[target_id]["actuals"]

        target_values = inputs[target_id].copy()

        for month_index in range(12):
            if source_actual[month_index] != 0:
                ratio = (
                    source_scenario[month_index]
                    / source_actual[month_index]
                )

                target_values[month_index] *= ratio ** elasticity

        inputs[target_id] = target_values

    # Apply integer rounding and min/max clamps to input KPIs.
    for kpi in kpis:
        if kpi.get("kind") != "input":
            continue

        kpi_id = kpi["id"]
        values = inputs[kpi_id]

        for month_index in range(12):
            value = values[month_index]

            if kpi.get("integer"):
                value = round_half_up(value)

            if "min" in kpi:
                value = max(value, kpi["min"])

            if "max" in kpi:
                value = min(value, kpi["max"])

            # Churn cannot be below zero.
            if kpi_id == "churn_pct":
                value = max(value, 0)

            values[month_index] = value

        monthly[kpi_id] = values

    # Read a KPI reference, including constants and lag.
    def get_reference(reference, month_index):
        if "const" in reference:
            return reference["const"]

        kpi_id = reference["kpi"]
        lag = reference.get("lag", 0)
        target_month = month_index - lag

        if target_month < 0:
            return definitions[kpi_id].get("prior", 0)

        return monthly[kpi_id][target_month]

    # Calculate formula KPIs month by month.
    previous_ytd_tax = 0
    cumulative_pbt = 0

    for month_index in range(12):
        for kpi in kpis:
            if kpi.get("kind") != "formula":
                continue

            kpi_id = kpi["id"]
            operation = kpi["op"]

            if operation == "ratio":
                numerator = get_reference(kpi["num"], month_index)
                denominator = get_reference(kpi["den"], month_index)

                value = (
                    numerator / denominator
                    if denominator != 0
                    else 0
                )

                value *= kpi.get("scale", 1)

            elif operation == "product":
                value = 1

                for factor in kpi["factors"]:
                    value *= get_reference(factor, month_index)

                value *= kpi.get("scale", 1)

            elif operation == "sum":
                value = 0

                for item in kpi["inputs"]:
                    amount = get_reference(item, month_index)
                    value += amount * item.get("sign", 1)

            elif operation == "step":
                check_value = get_reference(kpi["on"], month_index)
                value = 0

                for step in kpi["steps"]:
                    limit = step["upTo"]

                    if limit is None or check_value <= limit:
                        value = step["value"]
                        break

            elif operation == "ytd_tax":
                pbt = monthly[kpi["base"]][month_index]
                cumulative_pbt += pbt

                total_tax_so_far = max(cumulative_pbt, 0) * kpi["rate"]
                value = total_tax_so_far - previous_ytd_tax
                previous_ytd_tax = total_tax_so_far

            else:
                raise ValueError(
                    f"Unsupported formula operation: {operation}"
                )

            monthly[kpi_id].append(value)

    # Calculate financial-year values based on each KPI's FY rule.
    yearly = {}

    for kpi in kpis:
        kpi_id = kpi["id"]
        fy_rule = kpi.get("fy")

        values = monthly[kpi_id]

        if fy_rule == "sum":
            yearly[kpi_id] = sum(values)

        elif fy_rule == "last":
            yearly[kpi_id] = values[-1]

        elif fy_rule == "mean":
            yearly[kpi_id] = sum(values) / len(values)

        elif fy_rule == "recompute":
            if kpi_id == "net_margin_pct":
                profit = yearly["net_profit"]
                revenue = yearly["total_revenue"]

                yearly[kpi_id] = (
                    profit / revenue * 100
                    if revenue != 0
                    else 0
                )
            else:
                yearly[kpi_id] = values[-1]

    return {
        "monthly": monthly,
        "yearly": yearly,
    }


def calculate_baseline():
    return calculate_scenario({})